const { defineConfig } = require("@playwright/test"),
  base = require("./playwright.config.cjs");
module.exports = defineConfig({
  ...base,
  testDir: "./tests/migration",
  testMatch: "**/*.spec.cjs",
  timeout: 180000,
  retries: 0,
  outputDir: ".test-data/node-service-m4/browser-results",
  use: {
    ...base.use,
    userAgent:
      "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile/15E148 Safari/604.1",
  },
});
