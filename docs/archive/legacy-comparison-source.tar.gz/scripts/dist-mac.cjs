const fs = require("node:fs"),
  path = require("node:path");
const { spawnSync } = require("node:child_process");
const { packageConfig } = require("./package-config.cjs");
const { run: audit } = require("./audit-package.cjs");
const { digest } = require("./package-audit.cjs");
const root = path.resolve(__dirname, ".."),
  metadata = require("../package.json");
function parse(argv) {
  const options = { arch: process.arch, profile: "development" };
  for (let i = 0; i < argv.length; i++) {
    const key = { "--arch": "arch", "--profile": "profile" }[argv[i]];
    if (!key || !argv[i + 1]) throw Error("MAC_BUILD_ARGUMENTS");
    options[key] = argv[++i];
  }
  if (
    !["arm64", "x64"].includes(options.arch) ||
    !["development", "distribution"].includes(options.profile)
  )
    throw Error("MAC_BUILD_ARGUMENTS");
  return options;
}
function command(file, args, options = {}) {
  const result = spawnSync(file, args, {
    cwd: root,
    stdio: "inherit",
    ...options,
  });
  if (result.error || result.status !== 0)
    throw Error("MAC_BUILD_STEP_FAILED: " + path.basename(file));
  return result;
}
function signing(app) {
  const result = spawnSync(
    "/usr/bin/codesign",
    ["--display", "--verbose=4", app],
    { encoding: "utf8" },
  );
  const text = result.stderr || "";
  return {
    state:
      result.status !== 0
        ? "unsigned"
        : /Signature=adhoc/.test(text)
          ? "ad-hoc"
          : /Authority=Developer ID Application:/.test(text)
            ? "developer-id"
            : "other-signed",
    verified:
      spawnSync("/usr/bin/codesign", ["--verify", "--deep", "--strict", app], {
        stdio: "ignore",
      }).status === 0,
  };
}
function main(argv = process.argv.slice(2)) {
  const options = parse(argv);
  if (process.platform !== "darwin")
    throw Error("dist-mac 需要真实 macOS；当前平台未构建，未生成通过报告");
  if (
    options.profile === "distribution" &&
    metadata.scryletRuntimeDefault !== "node"
  )
    throw Error(
      "M4 迁移 / 新数据回退和 M5 默认切换尚未验收；只能构建显式隔离的 development 候选包",
    );
  const stage = path.join(
    root,
    "build/mac-" + options.arch + "-" + options.profile,
  );
  fs.mkdirSync(stage, { recursive: true });
  const report = {
    status: "running",
    platform: "darwin",
    hostArch: process.arch,
    targetArch: options.arch,
    version: metadata.version,
    profile: options.profile,
    installation: "unverified",
    nativeMouseObserver: false,
  };
  try {
    command(process.execPath, [
      path.join(root, "node_modules/typescript/bin/tsc"),
      "--noEmit",
      "-p",
      "phone/tsconfig.json",
    ]);
    command(process.execPath, [
      path.join(root, "node_modules/vite/bin/vite.js"),
      "build",
      "--config",
      "phone/vite.config.mts",
    ]);
    command(process.execPath, [
      path.join(root, "scripts/generate-icons.cjs"),
      "--mac",
    ]);
    const config = packageConfig({ platform: "darwin", ...options });
    config.directories.app = require("./node-package-stage.cjs").stageNodePackage(root, stage);
    config.files = config.files.map(file => typeof file === "object" && file.to === "phone-dist" ? { from: "phone-dist", to: "phone-dist", filter: ["**/*"] } : file);
    config.directories.output = path.join(stage, "output");
    if (options.profile === "distribution") config.mac.notarize = true;
    const file = path.join(stage, "builder.json");
    fs.writeFileSync(file, JSON.stringify(config, null, 2));
    command(
      process.execPath,
      [
        path.join(root, "node_modules/electron-builder/cli.js"),
        "--projectDir",
        root,
        "--config",
        file,
        "--mac",
        "dmg",
        "zip",
        "--" + options.arch,
        "--publish",
        "never",
      ],
      {
        env: {
          ...process.env,
          ...(options.profile === "development"
            ? { CSC_IDENTITY_AUTO_DISCOVERY: "false" }
            : {}),
        },
      },
    );
    const app = path.join(
      config.directories.output,
      options.arch === "arm64" ? "mac-arm64" : "mac",
      "Scrylet.app",
    );
    report.audit = audit([
      app,
      "--platform",
      "darwin",
      "--arch",
      options.arch,
      "--runtime",
      "node",
    ]);
    report.signing = signing(app);
    if (
      options.profile === "distribution" &&
      (report.signing.state !== "developer-id" ||
        !report.signing.verified ||
        spawnSync("/usr/bin/xcrun", ["stapler", "validate", app], {
          stdio: "ignore",
        }).status !== 0)
    )
      throw Error("MAC_DISTRIBUTION_SIGNATURE_OR_NOTARIZATION_UNVERIFIED");
    report.artifacts = [];
    fs.mkdirSync(path.join(root, "dist"), { recursive: true });
    for (const extension of ["dmg", "zip"]) {
      const name = `Scrylet-${metadata.version}-mac-${options.arch}.${extension}`,
        from = path.join(config.directories.output, name);
      if (!fs.existsSync(from) || fs.statSync(from).size === 0)
        throw Error("MAC_INSTALLER_MISSING");
      const target = path.join(root, "dist", name);
      fs.copyFileSync(from, target);
      const sha256 = digest(target);
      fs.writeFileSync(target + ".sha256", sha256 + "  " + name + "\n");
      report.artifacts.push({
        file: path.relative(root, target),
        bytes: fs.statSync(target).size,
        sha256,
      });
    }
    report.status = "built-not-installed";
    report.actualPackageRunArch = "unverified";
    report.app = path.relative(root, app);
  } catch (error) {
    report.status = "failed";
    report.code = error.message;
    throw error;
  } finally {
    fs.writeFileSync(
      path.join(stage, "package-check.json"),
      JSON.stringify(report, null, 2),
    );
    console.log(JSON.stringify(report));
  }
  return report;
}
if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
module.exports = { main, parse, signing };
