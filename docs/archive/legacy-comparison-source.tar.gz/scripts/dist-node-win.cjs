const fs = require("node:fs"),
  path = require("node:path"),
  { spawnSync } = require("node:child_process");
const { packageConfig } = require("./package-config.cjs");
function main(argv = process.argv.slice(2)) {
  if (process.platform !== "win32" || process.arch !== "x64")
    throw Error("轻量 Windows 包需要本机 Windows x64");
  if (argv.some((arg) => !["--dir"].includes(arg)))
    throw Error("仅支持 --dir；正式发行仍由完整 M5 证据控制");
  const root = path.resolve(__dirname, ".."),
    stage = path.join(root, "build/node-win-x64-candidate");
  fs.mkdirSync(stage, { recursive: true });
  const run = (args) => {
    const result = spawnSync(process.execPath, args, {
      cwd: root,
      stdio: "inherit",
    });
    if (result.error || result.status !== 0)
      throw Error("NODE_PACKAGE_BUILD_FAILED");
  };
  run(["scripts/setup.cjs"]);
  const config = packageConfig({
    platform: "win32",
    arch: "x64",
    profile: "node-candidate",
  });
  config.directories.app = require("./node-package-stage.cjs").stageNodePackage(
    root,
    stage,
  );
  config.files = config.files.map((file) =>
    typeof file === "object" && file.to === "phone-dist"
      ? { from: "phone-dist", to: "phone-dist", filter: ["**/*"] }
      : file,
  );
  config.directories.output = path.join(stage, "output");
  // Local pinned Electron avoids a redundant download. No dependency version changes.
  config.electronDist = path.join(root, "node_modules/electron/dist");
  const file = path.join(stage, "builder.json");
  fs.writeFileSync(file, JSON.stringify(config, null, 2));
  run([
    "node_modules/electron-builder/cli.js",
    "--config",
    file,
    "--win",
    ...(argv.includes("--dir") ? ["--dir"] : ["nsis"]),
    "--x64",
    "--publish",
    "never",
  ]);
  const audit = require("./audit-package.cjs").run([
    path.join(config.directories.output, "win-unpacked"),
    "--platform",
    "win32",
    "--arch",
    "x64",
    "--runtime",
    "node",
  ]);
  const report = {
    status: "candidate-built",
    defaultEngine: "node",
    productionDefault: "node",
    installation: "unverified",
    audit,
  };
  fs.writeFileSync(
    path.join(stage, "report.json"),
    JSON.stringify(report, null, 2),
  );
  console.log(JSON.stringify(report));
  return report;
}
if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(error.message);
    process.exitCode = 1;
  }
}
module.exports = { main };
