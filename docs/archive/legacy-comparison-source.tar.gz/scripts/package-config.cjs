const { NAME, APP_ID } = require("../desktop/brand.cjs");
function packageConfig({
  platform = process.platform,
  arch = process.arch,
  profile = platform === "darwin" ? "development" : "legacy",
} = {}) {
  if (
    !["win32", "darwin"].includes(platform) ||
    (platform === "win32" ? arch !== "x64" : !["x64", "arm64"].includes(arch))
  )
    throw Error("不支持的打包平台 / 架构");
  if (
    (platform === "win32" && !["legacy", "node-candidate"].includes(profile)) ||
    (platform === "darwin" &&
      !["development", "distribution"].includes(profile))
  )
    throw Error("未知的打包 profile");
  const config = {
    appId: APP_ID,
    productName: NAME,
    executableName: NAME,
    asar: true,
    npmRebuild: false,
    directories: { output: "dist", buildResources: "packaging" },
    files: [
      "desktop/**/*.cjs",
      "desktop/ui/**/*",
      "web/**/*",
      "config/providers.json",
      "config/prompts.json",
      "config/product-scope.json",
      "package.json",
      "LICENSE",
      "THIRD_PARTY_NOTICES.md",
      "service/**/*.cjs",
      "service/migrations/schema/*.sql",
      "service/migrations/legacy-schema.json",
      "contracts/**/*.cjs",
      "contracts/http-v1.json",
      { from: "build/phone", to: "phone-dist", filter: ["**/*"] },
    ],
    extraResources: [
      { from: "THIRD_PARTY_NOTICES.md", to: "THIRD_PARTY_NOTICES.md" },
      { from: "LICENSE", to: "LICENSE.txt" },
    ],
    win: {
      target: [{ target: "nsis", arch: ["x64"] }],
      icon: "packaging/icon.ico",
      artifactName: NAME + "-${version}-win-${arch}-Setup.${ext}",
    },
    nsis: {
      oneClick: false,
      perMachine: false,
      allowElevation: false,
      allowToChangeInstallationDirectory: true,
      createDesktopShortcut: true,
      createStartMenuShortcut: true,
      deleteAppDataOnUninstall: false,
      installerLanguages: ["zh_CN", "en_US"],
      language: "2052",
      license: "LICENSE",
      runAfterFinish: true,
    },
  };
  const nodeOnly = platform === "darwin" || profile === "node-candidate";
  if (nodeOnly) {
    config.files = config.files.filter(file => file !== "web/**/*");
    config.files.push(
      "!desktop/legacy-*.cjs",
      "web/brand/**/*", "web/pair.html", "web/pair.js", "web/pages.css",
      "web/models.html", "web/models.js", "web/unavailable.html", "web/unavailable.js", "web/quiet.js",
      "!node_modules/http-proxy/**/*", "!node_modules/requires-port/**/*", "!node_modules/eventemitter3/**/*",
    );
    const dependencies = { ...require("../package.json").dependencies };
    delete dependencies["http-proxy"];
    config.extraMetadata = { dependencies, scryletRuntimeDefault: "node", scryletBuild: {
      platform, arch, profile, runtime: "node-candidate", mouseObserver: platform === "win32", normalUserDataMigration: true,
    } };
  } else {
    // The explicit comparison package keeps its historical engine even though
    // source and Node-only candidates now default to the new implementation.
    config.extraMetadata = { scryletRuntimeDefault: "legacy" };
  }
  if (platform === "win32" && !nodeOnly)
    config.extraResources.push(
      { from: "build/python", to: "python" },
      { from: "runtime/launch.py", to: "runtime/launch.py" },
      { from: "desktop/mouse-input.py", to: "runtime/mouse-input.py" },
      { from: "runtime/requirements.lock", to: "runtime/requirements.lock" },
      {
        from: "build/native/win32-x64",
        to: "native/win32-x64",
        filter: [
          "input-observer.exe",
          "manifest.json",
          "NOTICE.txt",
          "licenses/**/*",
        ],
      },
    );
  if (platform === "win32" && nodeOnly) config.extraResources.push({
    from: "build/native/win32-x64", to: "native/win32-x64",
    filter: ["input-observer.exe", "manifest.json", "NOTICE.txt", "licenses/**/*"],
  });
  if (platform === "win32" && nodeOnly) {
    const { LAB_GUID, LAB_NAME } = require("./migration-install-profile.cjs");
    Object.assign(config.nsis, { guid: LAB_GUID, shortcutName: LAB_NAME, uninstallDisplayName: LAB_NAME, runAfterFinish: false, include: "packaging/node-candidate.nsh" });
  }
  if (platform === "darwin") {
    config.mac = {
      target: ["dmg", "zip"],
      icon: "packaging/icon.icns",
      category: "public.app-category.productivity",
      artifactName: NAME + "-${version}-mac-${arch}.${ext}",
      extendInfo: {
        NSLocalNetworkUsageDescription: "连接同一局域网中已配对的手机。",
        NSScreenCaptureUsageDescription:
          "仅在你截屏时读取屏幕，将图片发到已配对手机。",
      },
    };
    config.dmg = {
      title: NAME + " ${version}",
      format: "UDZO",
      contents: [
        { x: 130, y: 220, type: "file" },
        { x: 410, y: 220, type: "link", path: "/Applications" },
      ],
    };
    // No identity:null override: signing credentials remain controlled by the
    // explicit development/distribution wrapper and the macOS Keychain.
  }
  return config;
}
module.exports = { packageConfig };
