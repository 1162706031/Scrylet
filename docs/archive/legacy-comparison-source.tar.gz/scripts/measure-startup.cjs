// Real Electron + pinned legacy runtime + fresh browser contexts. No real keys.
const fs = require("node:fs");
const path = require("node:path");
const net = require("node:net");
const { performance } = require("node:perf_hooks");
const crypto = require("node:crypto");
const { execFileSync } = require("node:child_process");
const { _electron: electron, chromium, expect } = require("@playwright/test");
const { createMockProvider } = require("../tests/mock-provider.cjs");
const { defaults } = require("../desktop/capture-settings.cjs");
const { PHASES } = require("../desktop/startup-metrics.cjs");
const { parseOptions, bootInfo, assertNewBoot, summarize, systemInfo, packageSizes } = require("./startup-support.cjs");
const catalog = require("../config/providers.json");
const root = path.resolve(__dirname, "..");
const version = require("../package.json").version;

function write(file, value) {
  fs.writeFileSync(file + ".tmp", JSON.stringify(value, null, 2) + "\n", { mode: 0o600 });
  fs.renameSync(file + ".tmp", file);
}

function claimDirectory(directory) {
  const testRoot = path.resolve(root, ".test-data");
  directory = parseOptions(["--directory", directory]).directory;
  for (let current = directory; current !== path.dirname(testRoot); current = path.dirname(current)) {
    if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) throw new Error("测量目录不能使用符号链接或 junction");
  }
  if (fs.existsSync(directory) && fs.readdirSync(directory).length && !fs.existsSync(path.join(directory, "manifest.json")))
    throw new Error("目录没有测量标记，不接管已有数据");
  fs.mkdirSync(directory, { recursive: true });
}

function processTree(pid) {
  const executable = path.join(process.env.SystemRoot || "C:\\Windows", "System32/WindowsPowerShell/v1.0/powershell.exe");
  const entries = JSON.parse(execFileSync(executable, ["-NoProfile", "-NonInteractive", "-Command",
    "@(Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId) | ConvertTo-Json -Compress"],
  { encoding: "utf8", windowsHide: true, timeout: 15000 }));
  const ids = new Set([pid]);
  let count;
  do {
    count = ids.size;
    for (const entry of entries) if (ids.has(entry.ParentProcessId)) ids.add(entry.ProcessId);
  } while (ids.size !== count);
  return [...ids];
}

function alive(pid) { try { process.kill(pid, 0); return true; } catch (error) { if (error.code === "ESRCH") return false; throw error; } }
function listening(port) {
  return new Promise(resolve => {
    const socket = net.connect({ host: "127.0.0.1", port });
    socket.setTimeout(1000);
    const end = value => { socket.destroy(); resolve(value); };
    socket.once("connect", () => end(true));
    socket.once("error", () => end(false));
    socket.once("timeout", () => end(true));
  });
}

async function sample({ directory, browser, mock, boot, kind }) {
  let app, desktop, context, phase = "launch", metrics = null, closeResult = null, tree = [], gatewayPort;
  const pageErrors = [], data = path.join(directory, "data"), seed = path.join(directory, "seed");
  const sampleResult = { kind, bootId: boot.id, bootedAt: boot.bootedAt,
    bootUptimeSeconds: Math.floor((Date.now() - Date.parse(boot.bootedAt)) / 1000), at: new Date().toISOString() };
  try {
    const browserState = path.join(directory, "browser-state.json");
    context = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, locale: "zh-CN",
      ...(fs.existsSync(browserState) ? { storageState: browserState } : {}) });
    const phone = await context.newPage();
    phone.on("pageerror", () => pageErrors.push(true));
    const env = { ...process.env, SNAP_DATA_DIR: data, SNAP_LEGACY_DIR: seed, SNAP_STARTUP_METRICS: "1" };
    for (const key of ["ELECTRON_RUN_AS_NODE", "SNAP_PYTHON", "SNAP_PORT", "SNAP_RUNTIME_ENGINE"] ) delete env[key];
    for (const provider of catalog.providers) env[provider.envKey] = "";
    const launchedAt = performance.now();
    if (process.env.SNAP_TEST_MEMORY === "1") {
      const settingsFile = path.join(data, "capture-settings.json"), settings = JSON.parse(fs.readFileSync(settingsFile));
      settings.mouseEnabled = true; write(settingsFile, settings); sampleResult.nativeObserverEnabled = true;
    }
    app = await electron.launch({ args: [root], env, timeout: 120000 });
    desktop = await app.firstWindow();
    const observed = name => desktop.evaluate(phase => window.snap.startupObserved(phase), name);
    phase = "service-ready";
    await expect.poll(async () => {
      const state = await desktop.evaluate(() => window.snap.state());
      if (state.error) throw new Error("聊天服务启动失败");
      return state.ready;
    }, { timeout: 120000, intervals: [20, 50, 100] }).toBe(true);
    const state = await desktop.evaluate(() => window.snap.state());
    const url = new URL(state.baseUrl); url.hostname = "127.0.0.1"; gatewayPort = Number(url.port);
    const headers = { "X-Snap-Client": "mobile" };
    const paired = await phone.request.post(url.origin + "/snap/api/pair", { headers,
      data: { credential: new URLSearchParams(new URL(state.pairingUrl).hash.slice(1)).get("token"), name: "启动计时隔离手机" } });
    expect(paired.ok()).toBe(true);
    const providers = await (await phone.request.get(url.origin + "/snap/api/providers")).json();
    for (const provider of providers.providers) {
      expect(provider.configured).toBe(provider.id === "alibaba");
      if (provider.configured) expect(provider.baseUrl).toBe(mock.url);
    }
    phase = "phone-interactive";
    await phone.goto(url.origin);
    await expect(phone.locator("#snap-capture")).toBeEnabled({ timeout: 60000 });
    await expect(phone.locator("#chat-input")).toBeVisible();
    await observed("phone-interactive");
    sampleResult.controllerLaunchToInteractiveMs = Math.round((performance.now() - launchedAt) * 1000) / 1000;
    phase = "history-draft-and-submit";
    const historyResponse = await phone.request.get(url.origin + "/api/v1/chats/?page=1");
    expect(historyResponse.ok()).toBe(true);
    const history = await historyResponse.json(); expect(Array.isArray(history)).toBe(true);
    if (kind !== "initialization") expect(history.length).toBeGreaterThan(0);
    const draftText = "启动计时的本地模拟问题";
    await phone.locator("#chat-input").fill(draftText);
    await expect.poll(() => phone.evaluate(() => JSON.parse(sessionStorage.getItem("chat-input") || "{}").prompt),
      { timeout: 10000, intervals: [20] }).toBe(draftText);
    const count = mock.requests.length;
    await phone.locator("#send-message-button").click();
    await expect.poll(() => mock.requests.length, { timeout: 45000, intervals: [20] }).toBe(count + 1);
    expect(JSON.stringify(mock.requests.at(-1).messages)).toContain(draftText);
    await observed("usable");
    phase = "answer";
    await expect.poll(async () => (await phone.locator(".chat-assistant").last().innerText()).trim().length,
      { timeout: 45000, intervals: [20] }).toBeGreaterThan(0);
    await observed("answer-visible");
    await expect(phone.getByRole("button", { name: "停止", exact: true })).toBeHidden({ timeout: 45000 });
    await expect(phone).toHaveURL(/\/c\/[^/]+$/);
    const chatResponse = await phone.request.get(phone.url().replace("/c/", "/api/v1/chats/"));
    expect(chatResponse.ok()).toBe(true);
    const record = await chatResponse.json();
    expect(Object.values(record.chat.history.messages).some(message => message.role === "assistant" && message.content?.trim())).toBe(true);
    await observed("answer-completed");
    metrics = await desktop.evaluate(() => window.snap.startupMetrics());
    expect(metrics.schemaVersion).toBe(1);
    expect(metrics.phases.map(point => point.phase)).toEqual(PHASES);
    const uiResponse = metrics.phases.find(point => point.phase === "phone-interactive").elapsedMs;
    sampleResult.interactiveVerified = uiResponse >= 0;
    sampleResult.historyCountBefore = history.length;
    sampleResult.draftSaved = true;
    sampleResult.mockRequests = mock.requests.length - count;
    expect(pageErrors).toHaveLength(0);
    // Preserve this isolated browser's cookie so repeated app launches do not
    // bypass the product's eight-device limit or keep pairing new devices.
    write(path.join(directory, "browser-state.json"), await context.storageState());
    phase = "shutdown";
    tree = processTree(app.process().pid);
    if (process.env.SNAP_TEST_MEMORY === "1") {
      const measured = execFileSync("powershell.exe", ["-NoProfile", "-NonInteractive", "-Command", "@(Get-Process -Id " + tree.join(",") + " -ErrorAction SilentlyContinue | Select-Object ProcessName,WorkingSet64,PrivateMemorySize64) | ConvertTo-Json -Compress"], { encoding: "utf8", windowsHide: true, timeout: 15000 });
      const processes = JSON.parse(measured); expect(processes.some(p => p.ProcessName === "input-observer")).toBe(true);
      sampleResult.memory = { processes: processes.length, workingSetBytes: processes.reduce((n, p) => n + p.WorkingSet64, 0), privateBytes: processes.reduce((n, p) => n + p.PrivateMemorySize64, 0), includesNativeObserver: true, scope: "sum of app processes; shared pages may be counted more than once" };
    }
    const closingAt = performance.now();
    await context.close(); context = null;
    await app.evaluate(({ app }) => app.quit()).catch(() => {});
    await app.close(); app = null;
    await expect.poll(() => tree.filter(alive).length, { timeout: 10000, intervals: [50] }).toBe(0);
    await expect.poll(() => listening(gatewayPort), { timeout: 10000, intervals: [50] }).toBe(false);
    closeResult = { observedProcesses: tree.length, remainingProcesses: 0, gatewayReleased: true,
      elapsedMs: Math.round((performance.now() - closingAt) * 1000) / 1000 };
    return { ...sampleResult, status: "passed", metrics, shutdown: closeResult };
  } catch {
    if (desktop) metrics ||= await desktop.evaluate(() => window.snap.startupMetrics()).catch(() => null);
    return { ...sampleResult, status: "failed", failureStage: phase, code: "STARTUP_ACCEPTANCE_FAILED", metrics, shutdown: closeResult };
  } finally {
    await context?.close().catch(() => {});
    if (app) { await app.evaluate(({ app }) => app.quit()).catch(() => {}); await app.close().catch(() => {}); }
  }
}

async function main(args = process.argv.slice(2)) {
  const options = parseOptions(args), boot = bootInfo();
  claimDirectory(options.directory);
  const lock = path.join(options.directory, "measure.lock");
  const lockFd = fs.openSync(lock, "wx", 0o600);
  let mock, browser;
  try {
    const manifestFile = path.join(options.directory, "manifest.json");
    let manifest = fs.existsSync(manifestFile) ? JSON.parse(fs.readFileSync(manifestFile, "utf8")) :
      { schemaVersion: 1, engine: "legacy", version, providerPort: 0, prepared: false };
    if (manifest.schemaVersion !== 1 || manifest.engine !== "legacy" || manifest.version !== version ||
        !Number.isInteger(manifest.providerPort) || manifest.providerPort < 0 || manifest.providerPort > 65535)
      throw new Error("测量目录的版本或运行层不匹配");
    const samplesFile = path.join(options.directory, "samples.json");
    const samples = fs.existsSync(samplesFile) ? JSON.parse(fs.readFileSync(samplesFile, "utf8")) : [];
    if (!Array.isArray(samples)) throw new Error("测量记录格式无效");
    if (options.postReboot) {
      assertNewBoot(samples, boot);
      if (!manifest.prepared) throw Object.assign(new Error("系统重启采样前须在上一个启动周期准备隔离数据"), { code: "PREPARATION_REQUIRED" });
    }
    mock = await createMockProvider({ port: manifest.providerPort });
    manifest.providerPort = mock.provider.address().port; write(manifestFile, manifest);
    const seed = path.join(options.directory, "seed"); fs.mkdirSync(seed, { recursive: true });
    const provider = catalog.providers.find(item => item.id === "alibaba");
    write(path.join(seed, "api_keys.json"), { [provider.legacyKey]: "test-only-never-real" });
    write(path.join(seed, "proxy_api.json"), { enabled: true, apis: { alibaba: mock.url } });
    const data = path.join(options.directory, "data"); fs.mkdirSync(data, { recursive: true });
    const settingsFile = path.join(data, "capture-settings.json");
    if (!fs.existsSync(settingsFile)) write(settingsFile, { ...defaults(seed), mouseEnabled: false,
      fullShortcut: "Ctrl+Alt+Shift+F10", regionShortcut: "Ctrl+Alt+Shift+F11" });
    browser = await chromium.launch();
    async function run(kind) {
      const result = await sample({ directory: options.directory, browser, mock, boot, kind });
      samples.push(result); write(samplesFile, samples);
      write(path.join(options.directory, "summary.json"), { schemaVersion: 1, at: new Date().toISOString(),
        engine: "legacy", application: "source Electron app; packaged exe size only", version,
        system: systemInfo(), boot, summary: summarize(samples),
        sourceSha256: Object.fromEntries(["desktop/main.cjs", "desktop/preload.cjs", "desktop/runtime.cjs", "desktop/startup-metrics.cjs",
          "scripts/measure-startup.cjs", "scripts/startup-support.cjs", "tests/mock-provider.cjs"].map(file =>
          [file, crypto.createHash("sha256").update(fs.readFileSync(path.join(root, file))).digest("hex")])),
        methodology: { clock: "all phases use Electron main performance.now", browser: "Chromium, new context per launch",
          storageReady: "successful legacy authentication observes DB availability; not SQLite-open timestamp",
          usable: "history read + actual sessionStorage draft save + one loopback mock request observed",
          answerVisible: "first observed nonempty answer, 20ms poll + IPC; not provider first-token timing",
          cold: "distinct real OS boot required; operator must run before opening Scrylet after reboot" } });
      console.log(JSON.stringify({ kind, status: result.status, failureStage: result.failureStage,
        phases: result.metrics?.phases, shutdown: result.shutdown }));
      if (result.status !== "passed") throw new Error("启动采样失败，原始阶段记录已保留");
    }
    if (!manifest.prepared) {
      await run("initialization"); manifest.prepared = true; write(manifestFile, manifest);
    }
    if (!options.prepareOnly) for (let index = 0; index < options.runs; index++)
      await run(options.postReboot ? "post-system-reboot" : "process-restart");
    write(path.join(options.directory, "package-sizes.json"), packageSizes());
  } finally {
    const cleanup = await Promise.allSettled([browser?.close(), mock?.stop()]);
    fs.closeSync(lockFd); fs.rmSync(lock);
    if (cleanup.some(result => result.status === "rejected")) throw new Error("启动测量进程收尾失败");
  }
}

if (require.main === module) main().catch(error => {
  // Deliberately omit arbitrary Playwright errors, request bodies and URLs.
  const code = ["BOOT_ALREADY_SAMPLED", "PREPARATION_REQUIRED", "EEXIST"].includes(error.code) ? error.code : "STARTUP_MEASUREMENT_FAILED";
  console.error(JSON.stringify({ status: "failed", code })); process.exitCode = 1;
});
module.exports = { main, claimDirectory };
