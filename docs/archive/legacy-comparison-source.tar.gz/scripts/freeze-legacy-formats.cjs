const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { spawnSync } = require("node:child_process");
const root = path.resolve(__dirname, "..");
const base = path.join(root, ".test-data/node-service-formats"); fs.mkdirSync(base, { recursive: true });
const run = fs.mkdtempSync(path.join(base, "run-"));
function execute(args) {
  const result = spawnSync(process.execPath, args, { cwd: root, stdio: "inherit" });
  if (result.status !== 0) throw Error("FORMAT_CHECK_FAILED");
}
execute(["node_modules/@playwright/test/cli.js", "test", "--config", "playwright.formats.config.cjs", "--output", path.join(run, "results")]);
execute(["--test", "tests/provider-formats.test.cjs"]);
function reports(directory) {
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap(item => item.isDirectory()
    ? reports(path.join(directory, item.name)) : item.name === "report.json" ? [JSON.parse(fs.readFileSync(path.join(directory, item.name), "utf8"))] : []);
}
const browsers = reports(path.join(run, "results"));
if (browsers.length !== 2 || new Set(browsers.map(r => r.project)).size !== 2) throw Error("TWO_ENGINES_REQUIRED");
const source = path.resolve(root, browsers.find(r => r.project === "chromium").directory);
if (!source.startsWith(base + path.sep) || !fs.existsSync(path.join(source, "synthetic-only.json"))) throw Error("SYNTHETIC_SOURCE_REQUIRED");
const frozen = path.join(root, "tests/fixtures/legacy-v1");
if (!process.argv.includes("--update")) {
  const actual = JSON.parse(fs.readFileSync(path.join(source, "database-fixture.json"), "utf8"));
  const expected = JSON.parse(fs.readFileSync(path.join(frozen, "database.json"), "utf8"));
  const schema = snapshot => Object.fromEntries(Object.entries(snapshot.tables).map(([name, table]) =>
    [name, { sql: table.sql, columns: table.columns, foreignKeys: table.foreignKeys }]));
  require("node:assert/strict").deepEqual(schema(actual), schema(expected));
  require("node:assert/strict").deepEqual(actual.alembic, expected.alembic);
}
if (process.argv.includes("--update")) {
  fs.mkdirSync(frozen, { recursive: true });
  for (const [from, to] of [["database-fixture.json", "database.json"], ["browser-fixture.json", "browser.json"], ["desktop-fixture.json", "desktop.json"]]) {
    let content = fs.readFileSync(path.join(source, from), "utf8");
    content = content.replace(/http:\/\/127\.0\.0\.1:\d+/g, "http://127.0.0.1:49999");
    // Fail closed rather than publish an authentication field accidentally added upstream.
    if (/"(?:token|tokenHash|authorization|password|apiKey|access_token)"\s*:/i.test(content)) throw Error("FORBIDDEN_FIXTURE_FIELD");
    fs.writeFileSync(path.join(frozen, to), content + (content.endsWith("\n") ? "" : "\n"));
  }
}
execute(["--test", "tests/legacy-formats.test.cjs"]);
const hashes = Object.fromEntries(["database.json", "browser.json", "desktop.json"].map(name => [name,
  crypto.createHash("sha256").update(fs.readFileSync(path.join(frozen, name))).digest("hex")]));
const report = { task: "M0.4", testedAt: new Date().toISOString(), platform: process.platform, arch: process.arch,
  run: path.relative(root, run), browsers, frozenHashes: hashes, protocolChecks: 14, realAccounts: false,
  limits: ["No physical phone or macOS", "Migration and rollback implementations remain M4", "Five OS reboot first-launch samples remain untested"] };
fs.writeFileSync(path.join(run, "report.json"), JSON.stringify(report, null, 2) + "\n");
fs.writeFileSync(path.join(root, "artifacts/node-service-formats-check.json"), JSON.stringify(report, null, 2) + "\n");
console.log("Legacy formats and both mock protocols verified; default runtime remains legacy.");
