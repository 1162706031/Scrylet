// Explicit comparison only; normal `npm start` uses the Node implementation.
const path = require("node:path"),
  { spawn } = require("node:child_process");
const args = process.argv.slice(2);
if (args.length && (args.length !== 2 || args[0] !== "--data" || !path.isAbsolute(args[1])))
  throw Error("旧版对照仅接受可选的 --data 绝对路径");
const env = { ...process.env, SNAP_RUNTIME_ENGINE: "legacy" };
if (args.length) env.SNAP_DATA_DIR = path.resolve(args[1]);
else delete env.SNAP_DATA_DIR;
delete env.SNAP_MIGRATION_SOURCE;
delete env.ELECTRON_RUN_AS_NODE;
delete env.NODE_OPTIONS;
delete env.NODE_PATH;
const child = spawn(require("electron"), [path.resolve(__dirname, "..")], { env, stdio: "inherit" });
child.once("error", () => { process.exitCode = 1; });
child.once("exit", (code) => { process.exitCode = code ?? 1; });
