const { defineConfig } = require("@playwright/test");
const base = require("./playwright.config.cjs");

module.exports = defineConfig({
  ...base,
  testDir: "./tests/baseline",
  timeout: 180000,
  outputDir: ".test-data/node-service-baseline/results",
  use: { ...base.use, actionTimeout: 15000 },
  retries: 0,
});
