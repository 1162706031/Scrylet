const http = require("node:http");
const { setTimeout: delay } = require("node:timers/promises");

async function createMockProvider({ port = 0 } = {}) {
  const requests = [],
    closed = [];
  const provider = http.createServer(async (request, response) => {
    if (
      !request.url.endsWith("/chat/completions") &&
      !request.url.endsWith("/responses")
    ) {
      response.writeHead(404);
      response.end();
      return;
    }
    let raw = "";
    for await (const chunk of request) raw += chunk;
    const payload = JSON.parse(raw);
    requests.push(payload);
    if (request.url.endsWith("/responses")) {
      response.writeHead(200, { "Content-Type": "application/json" });
      response.end(
        JSON.stringify({
          id: "resp_mock",
          object: "response",
          created_at: Math.floor(Date.now() / 1000),
          status: "completed",
          model: payload.model,
          output: [
            {
              id: "msg_mock",
              type: "message",
              role: "assistant",
              status: "completed",
              content: [
                {
                  type: "output_text",
                  text: "Responses 多模态转换已验证",
                  annotations: [],
                },
              ],
            },
          ],
          usage: { input_tokens: 5, output_tokens: 5, total_tokens: 10 },
        }),
      );
      return;
    }
    response.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
    });
    const slow = JSON.stringify(payload.messages).includes("慢速测试");
    let done = false;
    response.on("close", () => {
      closed.push({ slow, completed: done });
    });
    const content = slow
      ? "正在逐步分析。".repeat(300)
      : requests.length === 1
        ? "## 第一步：理解问题\n\n截图已收到。这是本地模拟模型的验证回答。\n\n由 $a^2+b^2=c^2$，代入可得 **c = 5**。\n\n~~~python\nprint(3 ** 2 + 4 ** 2)\n~~~\n"
        : "追问已收到。前一轮的截图和对话上下文都保留了。\n\n答案仍然是 **5**。";
    for (
      let index = 0;
      index < content.length && !response.destroyed;
      index += 8
    ) {
      response.write(
        "data: " +
          JSON.stringify({
            id: "test-completion",
            object: "chat.completion.chunk",
            model: payload.model,
            choices: [
              {
                index: 0,
                delta: { content: content.slice(index, index + 8) },
                finish_reason: null,
              },
            ],
          }) +
          "\n\n",
      );
      await delay(slow ? 100 : 15);
    }
    if (!response.destroyed) {
      done = true;
      response.write(
        "data: " +
          JSON.stringify({
            id: "test-completion",
            choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
          }) +
          "\n\ndata: [DONE]\n\n",
      );
      response.end();
    }
  });
  if (!port) await require("../service/listen.cjs").listenAutomatic(provider);
  else await new Promise((resolve, reject) => provider.once("error", reject).listen(port, "127.0.0.1", resolve));
  return { provider, requests, closed, url: "http://127.0.0.1:" + provider.address().port + "/v1",
    async stop() {
      provider.closeAllConnections();
      await new Promise((resolve, reject) => provider.close(error => error ? reject(error) : resolve()));
    },
  };
}
module.exports = { createMockProvider };
