const path = require("node:path");
const { Runtime } = require("../desktop/runtime.cjs");
const { Gateway } = require("../desktop/gateway.cjs");
const { createMockProvider } = require("./mock-provider.cjs");
const catalog = require("../config/providers.json");

async function createFixture(directory) {
  const { provider, requests, closed } = await createMockProvider();
  const oldEnv = {};
  for (const item of catalog.providers) {
    oldEnv[item.envKey] = process.env[item.envKey];
    delete process.env[item.envKey];
  }
  const runtime = new Runtime(directory, {
    engine: "legacy",
    legacyDirectory: path.join(directory, "no-legacy"),
  });
  const svg =
    '<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="900"><rect width="1440" height="900" fill="#f3f5f2"/><rect x="200" y="180" width="1040" height="540" rx="24" fill="white"/><text x="260" y="275" font-family="sans-serif" font-size="36" fill="#24392d">Mathematics · Practice 01</text><text x="260" y="370" font-family="sans-serif" font-size="28" fill="#52654c">A right triangle has sides a = 3, b = 4.</text><text x="260" y="425" font-family="sans-serif" font-size="28" fill="#52654c">Find the hypotenuse c, and explain each step.</text><path d="M300 610h280L300 480z" fill="none" stroke="#81936e" stroke-width="5"/><text x="420" y="645" font-size="24">4</text><text x="265" y="550" font-size="24">3</text><text x="430" y="525" font-size="24">c = ?</text></svg>';
  const captures = [];
  const native = {
    permission: () => "granted",
    displays: () => [
      { id: "1", name: "测试屏幕", width: 1440, height: 900, primary: true },
      { id: "2", name: "第二块屏幕", width: 1440, height: 900, primary: false },
    ],
    capture: async (displayId) => {
      captures.push({ displayId: displayId === "2" ? "2" : "1" });
      const numbered = svg.replace(
        "</svg>",
        '<text x="260" y="690" font-family="sans-serif" font-size="20" fill="#87957e">Screen ' +
          captures.at(-1).displayId +
          " / Capture " +
          captures.length +
          "</text></svg>",
      );
      return {
        image:
          "data:image/svg+xml;base64," +
          Buffer.from(numbered).toString("base64"),
        width: 1440,
        height: 900,
        displayId: captures.at(-1).displayId,
      };
    },
  };
  const gateway = new Gateway(directory, native, runtime);
  await gateway.start();
  const url =
    "http://" +
    (process.env.SNAP_TEST_HOST || "127.0.0.1") +
    ":" +
    gateway.port;
  try {
    await runtime.start();
  } finally {
    for (const item of catalog.providers) {
      if (oldEnv[item.envKey] === undefined) delete process.env[item.envKey];
      else process.env[item.envKey] = oldEnv[item.envKey];
    }
  }
  await runtime.saveProvider("alibaba", {
    apiKey: "test-only-never-real",
    baseUrl: "http://127.0.0.1:" + provider.address().port + "/v1",
  });
  return {
    url,
    runtime,
    gateway,
    requests,
    closed,
    captures,
    providerUrl: "http://127.0.0.1:" + provider.address().port + "/v1",
    pairingUrl: url + "/snap/pair#token=" + gateway.pairing.info().token,
    async stop() {
      await gateway.close();
      await runtime.stop();
      provider.closeAllConnections();
      await new Promise((resolve) => provider.close(resolve));
    },
  };
}
module.exports = { createFixture };
