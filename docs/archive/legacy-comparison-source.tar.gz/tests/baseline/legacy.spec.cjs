// Freeze reachable product behavior against the pinned, isolated legacy UI.
// These checks remain separate from the future Node acceptance suite.
const { test, expect } = require("@playwright/test");
const fs = require("node:fs");
const path = require("node:path");
const { createFixture } = require("../fixture.cjs");
let fixture;

test.beforeAll(async () => {
  const root = path.resolve(".test-data/node-service-baseline");
  fs.mkdirSync(root, { recursive: true });
  const directory = fs.mkdtempSync(path.join(root, "legacy-"));
  fixture = await createFixture(directory);
});
test.afterAll(async () => { await fixture?.stop(); });
test.beforeEach(async ({ page }) => {
  for (const device of fixture.gateway.pairing.list()) fixture.gateway.revoke(device.id);
  await page.goto(fixture.pairingUrl);
  await expect(page.locator("#snap-capture")).toBeEnabled({ timeout: 60000 });
});

async function send(page, text) {
  const before = fixture.requests.length;
  await page.locator("#chat-input").fill(text);
  await page.locator("#send-message-button").click();
  await expect.poll(() => fixture.requests.length).toBe(before + 1);
  await expect(page.getByRole("button", { name: "停止", exact: true })).toBeHidden();
  await expect(page).toHaveURL(/\/c\/[^/]+$/);
  return new URL(page.url()).pathname.split("/").at(-1);
}

async function sidebar(page) {
  if (!(await page.locator("#sidebar").count()) ||
      await page.locator("#sidebar").getAttribute("data-state") !== "true")
    await page.locator("#sidebar-toggle-button").click();
  await expect(page.locator("#sidebar")).toHaveAttribute("data-state", "true");
}

async function chatMenu(page, id) {
  await sidebar(page);
  const row = page.locator(`#sidebar a[href="/c/${id}"]`);
  await expect(row).toBeVisible();
  const trigger = row.locator("xpath=../..").locator('button[aria-label="对话菜单"]');
  const wrapper = trigger.locator('xpath=ancestor::span[@aria-expanded][1]');
  if (await wrapper.getAttribute("aria-expanded") !== "true") await trigger.click();
}

test("F21 会话菜单：重命名、置顶、搜索、下载与删除实际可用", async ({ page }, info) => {
  const id = await send(page, "基线管理入口");
  await chatMenu(page, id);
  // The sidebar popup uses buttons, not role=menuitem; inspect actual UI.
  for (const name of ["下载", "重命名", "标记为未读", "置顶", "归档", "删除"])
    await expect(page.getByRole("button", { name, exact: true })).toBeVisible();
  await page.screenshot({ path: info.outputPath("conversation-menu.png") });
  await page.getByRole("button", { name: "重命名", exact: true }).click();
  const title = page.locator(`[id="chat-title-input-${id}"]`);
  await title.fill("已重命名的隔离会话");
  await title.press("Enter");
  await expect.poll(async () => (await fixture.runtime.request(`/api/v1/chats/${id}`)).title)
    .toBe("已重命名的隔离会话");
  await chatMenu(page, id);
  await page.getByRole("button", { name: "置顶", exact: true }).click();
  await expect.poll(async () => (await fixture.runtime.request(`/api/v1/chats/${id}`)).pinned).toBe(true);
  await chatMenu(page, id);
  await expect(page.getByRole("button", { name: "取消置顶", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "取消置顶", exact: true }).click();
  await page.locator("#sidebar-search-button").click();
  await page.screenshot({ path: info.outputPath("conversation-search.png") });
  await expect(page.getByPlaceholder(/搜索/).first()).toBeVisible();
  await page.getByPlaceholder(/搜索/).first().fill("已重命名的隔离会话");
  await expect(page.getByText("已重命名的隔离会话", { exact: true }).last()).toBeVisible();
  await page.keyboard.press("Escape");
  await chatMenu(page, id);
  await page.getByRole("button", { name: "下载", exact: true }).hover();
  await page.screenshot({ path: info.outputPath("conversation-download.png") });
  await expect(page.getByRole("button", { name: /\.json/i })).toBeVisible();
  const downloading = page.waitForEvent("download");
  await page.getByRole("button", { name: /\.json/i }).click();
  const download = await downloading;
  await download.saveAs(info.outputPath("export.json"));
  const exported = JSON.parse(fs.readFileSync(info.outputPath("export.json"), "utf8"));
  expect(JSON.stringify(exported)).toContain(id);
  await page.keyboard.press("Escape");
  await page.keyboard.press("Escape");
  await expect(page.getByRole("button", { name: "重命名", exact: true })).toBeHidden();
  await chatMenu(page, id);
  await page.getByRole("button", { name: "删除", exact: true }).click();
  await page.screenshot({ path: info.outputPath("conversation-delete.png") });
  await page.getByRole("button", { name: "确认", exact: true }).click();
  await expect(page.locator(`#sidebar a[href="/c/${id}"]`)).toHaveCount(0);
});

test("F21 编辑和重答保留消息图与可切换分支", async ({ page }, info) => {
  const id = await send(page, "原始用户问题");
  const original = await fixture.runtime.request(`/api/v1/chats/${id}`);
  const originalIds = Object.keys(original.chat.history.messages);
  expect(originalIds).toHaveLength(2);
  const beforeRegenerate = fixture.requests.length;
  await page.locator('button[aria-label="重新生成"]').click();
  await page.getByRole("button", { name: "重试", exact: true }).click();
  await expect.poll(() => fixture.requests.length).toBe(beforeRegenerate + 1);
  await expect.poll(async () => Object.keys((await fixture.runtime.request(`/api/v1/chats/${id}`)).chat.history.messages).length).toBe(3);
  await expect(page.getByRole("button", { name: "停止", exact: true })).toBeHidden();
  await page.screenshot({ path: info.outputPath("answer-branches.png") });
  // The legacy user action uses hover-reveal / focus-within. Freeze the
  // keyboard-focus path; a touch-only reveal remains a separate acceptance.
  const editUser = page.locator('.user-message button[aria-label="编辑"]').first();
  await editUser.focus();
  await editUser.click();
  await page.screenshot({ path: info.outputPath("edit-user-message.png") });
  const input = page.locator("textarea").filter({ visible: true }).first();
  await input.fill("编辑后的用户问题");
  const before = fixture.requests.length;
  await page.locator(".user-message").getByRole("button", { name: "发送", exact: true }).click();
  await expect.poll(() => fixture.requests.length).toBe(before + 1);
  await expect(page.getByRole("button", { name: "停止", exact: true })).toBeHidden();
  const edited = await fixture.runtime.request(`/api/v1/chats/${id}`);
  const messages = edited.chat.history.messages;
  for (const old of originalIds) expect(messages).toHaveProperty(old);
  expect(Object.keys(messages)).toHaveLength(5);
  expect(Object.values(messages).filter(m => m.role === "user").map(m => m.content))
    .toEqual(expect.arrayContaining(["原始用户问题", "编辑后的用户问题"]));
  await page.screenshot({ path: info.outputPath("user-branches.png") });
  await page.locator('.user-message button[aria-label="上一条消息"]').click();
  await expect(page.locator(".user-message")).toContainText("原始用户问题");
  await expect.poll(async () => {
    const record = await fixture.runtime.request(`/api/v1/chats/${id}`);
    const chat = record.chat;
    // Match the pinned loader's precedence. Merely browsing a sibling branch
    // is transient in this legacy UI; the saved selection remains unchanged.
    const current = chat.history.messages[record.current_message_id]
      ? record.current_message_id : chat.history.currentId;
    let message = chat.history.messages[current];
    while (message.parentId) message = chat.history.messages[message.parentId];
    return message.content;
  }).toBe("编辑后的用户问题");
  const selected = await fixture.runtime.request(`/api/v1/chats/${id}`);
  fs.writeFileSync(info.outputPath("branch-pointers.json"), JSON.stringify({
    current_message_id: selected.current_message_id,
    embeddedCurrentId: selected.chat.history.currentId,
    messageIds: Object.keys(selected.chat.history.messages),
  }, null, 2));
  await page.reload();
  await expect(page.locator(".user-message")).toContainText("编辑后的用户问题");
});

test("F21 补充入口：标记全部已读、克隆和归档、会话分组折叠", async ({ page }, info) => {
  const id = await send(page, "核对补充管理操作");
  const before = fixture.requests.length;
  await sidebar(page);
  await page.locator('#sidebar button[aria-label="更多"]').click();
  await page.getByText("标记全部已读", { exact: true }).click();
  await chatMenu(page, id);
  await expect(page.getByRole("button", { name: "分享", exact: true })).toBeVisible();
  await page.getByRole("button", { name: "克隆", exact: true }).click();
  await expect(page).not.toHaveURL(fixture.url + `/c/${id}`);
  await expect(page).toHaveURL(/\/c\/[^/]+$/);
  const clonedId = new URL(page.url()).pathname.split("/").at(-1);
  await expect.poll(async () => Object.keys((await fixture.runtime.request(`/api/v1/chats/${clonedId}`)).chat.history.messages).length).toBe(2);
  expect(fixture.requests.length).toBe(before);
  await chatMenu(page, clonedId);
  await page.getByRole("button", { name: "归档", exact: true }).click();
  await expect.poll(async () => (await fixture.runtime.request(`/api/v1/chats/${clonedId}`)).archived).toBe(true);
  await sidebar(page);
  await page.locator("#sidebar").getByRole("button", { name: "对话", exact: true }).click();
  await expect(page.locator(`#sidebar a[href="/c/${id}"]`)).toBeHidden();
  await page.screenshot({ path: info.outputPath("conversation-group-collapsed.png") });
  fs.writeFileSync(info.outputPath("conversation-group.txt"), await page.locator("body").ariaSnapshot());
});

test("F23 新对话和已有会话草稿键、图片引用、刷新与切换", async ({ page }, info) => {
  const editor = page.locator("#chat-input");
  await editor.fill("已保存的新对话草稿");
  await page.locator("#snap-capture").click();
  await expect.poll(() => page.evaluate(() => {
    const value = JSON.parse(sessionStorage.getItem("chat-input") || "{}");
    return { prompt: value.prompt, files: value.files?.length };
  })).toEqual({ prompt: "已保存的新对话草稿", files: 1 });
  const draft = await page.evaluate(() => JSON.parse(sessionStorage.getItem("chat-input")));
  // Only synthetic input is saved. Never export localStorage auth tokens.
  fs.writeFileSync(info.outputPath("new-chat-draft.json"), JSON.stringify(draft, null, 2));
  await page.reload();
  await expect(editor).toHaveText("已保存的新对话草稿");
  await expect(page.locator(".snap-attachment")).toHaveCount(1);
  const id = await send(page, "创建历史会话");
  await editor.fill("此历史会话的草稿");
  await page.locator("#snap-capture").click();
  await expect.poll(() => page.evaluate(key => {
    const value = JSON.parse(sessionStorage.getItem(key) || "{}");
    return { prompt: value.prompt, files: value.files?.length };
  }, `chat-input-${id}`)).toEqual({ prompt: "此历史会话的草稿", files: 1 });
  await page.reload();
  await expect(editor).toHaveText("此历史会话的草稿");
  await expect(page.locator(".snap-attachment")).toHaveCount(1);
  await sidebar(page);
  await page.locator("#sidebar a#sidebar-new-chat-button").click();
  await expect(page).toHaveURL(fixture.url + "/");
  await page.screenshot({ path: info.outputPath("new-chat-after-history-draft.png") });
  const newDraft = await editor.innerText();
  fs.writeFileSync(info.outputPath("draft-switch.json"), JSON.stringify({
    source: "sessionStorage", newChatKey: "chat-input", existingChatKey: "chat-input-<chatId>",
    newChatTextAfterSwitch: newDraft,
    fileKeys: Object.keys(draft.files[0]).sort(),
  }, null, 2));
  // Freeze what actually remains after the visible new-chat action.
  expect(newDraft.trim()).toBe("");
  await sidebar(page);
  await page.locator(`#sidebar a[href="/c/${id}"]`).click();
  await expect(editor).toHaveText("此历史会话的草稿");
  await expect(page.locator(".snap-attachment")).toHaveCount(1);
});
