// Supplemental M2 comparison: save-only editing was reachable but not executed in M0.
const { test, expect } = require("@playwright/test");
const fs = require("node:fs"), path = require("node:path");
const { createFixture } = require("../fixture.cjs");
let fixture;
test.beforeAll(async () => { const root = path.resolve(".test-data/node-service-m2/legacy-save"); fs.mkdirSync(root, { recursive: true }); fixture = await createFixture(fs.mkdtempSync(path.join(root, "data-"))); });
test.afterAll(async () => fixture?.stop());
test("M2 legacy comparison save-only user and assistant retain IDs, children and request count", async ({ page }, info) => {
  await page.goto(fixture.pairingUrl); await expect(page.locator("#snap-capture")).toBeEnabled({ timeout: 60000 });
  await page.locator("#chat-input").fill("旧版保存原问题"); await page.locator("#send-message-button").click(); await expect.poll(() => fixture.requests.length).toBe(1); await expect(page.getByRole("button", { name: "停止", exact: true })).toBeHidden();
  const chatId = new URL(page.url()).pathname.split("/").at(-1), original = await fixture.runtime.request("/api/v1/chats/" + chatId);
  const ids = Object.keys(original.chat.history.messages), evidence = { messageCount: ids.length, userSaved: false, assistantSaved: false, noExtraRequest: false, idsAndChildrenRetained: false };
  for (const [index, content] of [[0, "保存但不重发的问题"], [1, "保存但不重答的回答"]]) {
    const edit = page.getByRole("button", { name: "编辑", exact: true }).nth(index); await edit.focus(); await edit.click();
    await page.locator("textarea").filter({ visible: true }).first().fill(content); await page.locator("button:not(.save-code-button)").filter({ hasText: /^保存$/ }).filter({ visible: true }).click();
    await expect.poll(async () => Object.values((await fixture.runtime.request("/api/v1/chats/" + chatId)).chat.history.messages).some(m => m.content === content)).toBe(true);
    const record = await fixture.runtime.request("/api/v1/chats/" + chatId); expect(Object.keys(record.chat.history.messages)).toEqual(ids);
    for (const id of ids) expect(record.chat.history.messages[id].childrenIds).toEqual(original.chat.history.messages[id].childrenIds);
    if (index === 0) evidence.userSaved = true; else evidence.assistantSaved = true;
  }
  expect(fixture.requests.length).toBe(1); evidence.noExtraRequest = true; evidence.idsAndChildrenRetained = true;
  fs.writeFileSync(info.outputPath("legacy-save-summary.json"), JSON.stringify(evidence, null, 2)); await page.screenshot({ path: info.outputPath("legacy-save.png") });
});
