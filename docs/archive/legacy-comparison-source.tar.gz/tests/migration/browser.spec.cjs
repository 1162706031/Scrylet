const { test, expect } = require("@playwright/test"),
  fs = require("node:fs"),
  path = require("node:path"),
  { migrationBrowser } = require("./browser-fixture.cjs");
test("M4 same-origin old saved draft / image / preferences -> Node -> saved new draft -> actual old rollback", async ({
  page,
}, info) => {
  const f = await migrationBrowser();
  try {
    await page.goto(f.pairingUrl);
    await page.goto(f.url + "/c/" + f.chatId);
    await expect(page.locator("#chat-input")).toBeVisible({ timeout: 60000 });
    await page.locator("#chat-input").fill("旧版已保存的图文草稿");
    await page.locator("#snap-capture").click();
    await expect
      .poll(() =>
        page.evaluate(
          (key) =>
            JSON.parse(sessionStorage.getItem(key) || "{}").files?.length,
          "chat-input-" + f.chatId,
        ),
      )
      .toBe(1);
    await page.evaluate(() => {
      localStorage.setItem("snap.readAloud", "false");
      localStorage.setItem("snap.speechVoice", "preserved:voice");
      localStorage.setItem("snap.speechRate", "1.1");
      localStorage.setItem("snap.display", "fixture-screen");
      localStorage.setItem(
        "snap.crop.fixture-screen",
        JSON.stringify({
          width: 96,
          height: 64,
          data: { x: 1, y: 2, width: 90, height: 60 },
        }),
      );
      localStorage.setItem("unrelated-user-setting", "keep-me");
    });
    const before = await page.evaluate(
        (key) => sessionStorage.getItem(key),
        "chat-input-" + f.chatId,
      ),
      count = await f.count();
    const progressEvent = f.app.waitForEvent("window"),
      upgrading = f.upgrade({ pauseAtData: true });
    const progress = await progressEvent;
    await expect(progress.locator("progress")).toHaveJSProperty("value", 4);
    expect(await progress.evaluate(() => document.documentElement.scrollHeight <= innerHeight && document.documentElement.scrollWidth <= innerWidth)).toBe(true);
    await progress.screenshot({
      path: path.resolve(
        "artifacts/node-service-m4-migration-" + info.project.name + ".png",
      ),
    });
    await f.resume();
    const next = await upgrading;
    expect(next.url).toBe(f.url);
    await page.reload();
    await expect(page.locator("#chat-input")).toHaveValue(
      "旧版已保存的图文草稿",
    );
    await expect(page.locator(".attachment")).toHaveCount(1);
    await expect
      .poll(() =>
        page.evaluate(
          () =>
            JSON.parse(localStorage.getItem("snap.browserMigration.v1") || "{}")
              .status,
        ),
      )
      .toBe("validated");
    expect(
      await page.evaluate(
        (key) => localStorage.getItem("snap.legacyDraft.original.v1:" + key),
        f.chatId,
      ),
    ).toBe(before);
    expect(await f.count()).toBe(count);
    const preferences = await page.evaluate(() =>
      Object.fromEntries(
        [
          "snap.readAloud",
          "snap.speechVoice",
          "snap.speechRate",
          "snap.display",
          "snap.crop.fixture-screen",
          "unrelated-user-setting",
        ].map((k) => [k, localStorage.getItem(k)]),
      ),
    );
    expect(preferences["snap.readAloud"]).toBe("false");
    expect(preferences["snap.speechVoice"]).toBe("preserved:voice");
    expect(preferences["unrelated-user-setting"]).toBe("keep-me");
    const legacyFile = JSON.parse(before).files[0].id,
      oldURL = await page.request.get(
        next.url + "/api/v1/files/" + legacyFile + "/content",
      );
    expect(oldURL.ok()).toBe(true);
    await page.locator("#chat-input").fill("新版继续修改后也要能回退");
    await expect
      .poll(() =>
        page.evaluate(
          (key) =>
            JSON.parse(sessionStorage.getItem("chat-input-" + key) || "{}")
              .prompt,
          f.chatId,
        ),
      )
      .toBe("新版继续修改后也要能回退");
    await expect(page.getByText("已保存", { exact: true })).toBeVisible();
    await page.screenshot({
      path: path.resolve(
        "artifacts/node-service-m4-upgraded-" + info.project.name + ".png",
      ),
    });
    const old = await f.rollback();
    expect(old.url).toBe(f.url);
    await page.reload();
    await expect(page.locator("#chat-input")).toHaveText(
      "新版继续修改后也要能回退",
      { timeout: 60000 },
    );
    await expect(page.locator(".snap-attachment")).toHaveCount(1);
    expect(await f.count()).toBe(count);
    expect(
      await page.evaluate(() => localStorage.getItem("unrelated-user-setting")),
    ).toBe("keep-me");
    await page.screenshot({
      path: path.resolve(
        "artifacts/node-service-m4-rollback-" + info.project.name + ".png",
      ),
    });
    fs.writeFileSync(
      path.join(f.directory, "browser-report.json"),
      JSON.stringify({
        status: "passed",
        project: info.project.name,
        sameOrigin: true,
        oldSavedDraft: true,
        newSavedDraftRollback: true,
        oldAuthenticatedFileURL: true,
        prefs: preferences,
        modelRequestsDuringMigration: 0,
      }),
    );
  } finally {
    await f.stop();
  }
});
test("M4 port conflict keeps original browser storage; restoring original origin enables migration", async ({
  page,
}, info) => {
  const f = await migrationBrowser();
  try {
    await page.goto(f.pairingUrl);
    await page.goto(f.url + "/c/" + f.chatId);
    await expect(page.locator("#chat-input")).toBeVisible({ timeout: 60000 });
    await page.locator("#chat-input").fill("原 origin 的已保存文字");
    await expect
      .poll(() =>
        page.evaluate(
          (key) =>
            JSON.parse(sessionStorage.getItem("chat-input-" + key) || "{}")
              .prompt,
          f.chatId,
        ),
      )
      .toBe("原 origin 的已保存文字");
    const original = await page.evaluate(
      (key) => sessionStorage.getItem("chat-input-" + key),
      f.chatId,
    );
    const next = await f.upgrade({ occupyPort: true });
    expect(next.url).not.toBe(f.url);
    await page.goto(next.url + "/c/" + f.chatId);
    await expect(page.locator("#chat-input")).toHaveValue("");
    expect(
      await page.evaluate(
        (key) => sessionStorage.getItem("chat-input-" + key),
        f.chatId,
      ),
    ).toBeNull();
    await page.goto(f.url + "/probe");
    expect(
      await page.evaluate(
        (key) => sessionStorage.getItem("chat-input-" + key),
        f.chatId,
      ),
    ).toBe(original);
    const restored = await f.restoreOrigin();
    expect(restored.url).toBe(f.url);
    await page.goto(restored.url + "/c/" + f.chatId);
    await expect(page.locator("#chat-input")).toHaveValue(
      "原 origin 的已保存文字",
    );
    expect(await f.count()).toBe(0);
    fs.writeFileSync(
      path.join(f.directory, "browser-report.json"),
      JSON.stringify({
        status: "passed",
        project: info.project.name,
        crossOriginAutoRead: false,
        sourceStoragePreserved: true,
        restoredOriginMigration: true,
        modelRequests: 0,
      }),
    );
  } finally {
    await f.stop();
  }
});
