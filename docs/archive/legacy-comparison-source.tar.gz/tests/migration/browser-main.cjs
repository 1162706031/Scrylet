const electron = require("electron"),
  { app, safeStorage } = electron,
  fs = require("node:fs"),
  path = require("node:path");
const directory = process.env.SNAP_MIGRATION_BROWSER_DIR;
if (!directory || !path.isAbsolute(directory)) process.exit(2);
app.setPath("userData", path.join(directory, "node"));
app.on("window-all-closed", () => {});
const { Runtime } = require("../../desktop/legacy-runtime.cjs"),
  { NodeRuntime } = require("../../desktop/node-runtime.cjs"),
  { Gateway } = require("../../desktop/gateway.cjs"),
  { legacyFixture } = require("./fixture.cjs"),
  { migrateLegacy, rollbackLegacy } = require("../../desktop/migration.cjs");
const source = path.join(directory, "legacy"),
  target = path.join(directory, "node"),
  rollback = path.join(directory, "rollback");
let runtime, gateway, mock, blocker, progress, resume;
const native = {
  permission: () => "granted",
  displays: () => [
    {
      id: "fixture-screen",
      name: "隔离测试屏幕",
      width: 96,
      height: 64,
      primary: true,
    },
  ],
  capture: async () => ({
    displayId: "fixture-screen",
    width: 96,
    height: 64,
    image:
      "data:image/png;base64," +
      require("../phone/helpers.cjs").png.toString("base64"),
  }),
};
const state = () => ({
  url: "http://127.0.0.1:" + gateway.port,
  pairingUrl:
    "http://127.0.0.1:" +
    gateway.port +
    "/snap/pair#token=" +
    gateway.pairing.info().token,
  chatId: require("../fixtures/legacy-v1/database.json").tables.chat.rows[0].id,
});
async function stop() {
  await gateway?.close();
  await runtime?.stop();
  gateway = runtime = null;
}
app
  .whenReady()
  .then(async () => {
    mock =
      await require("../fixtures/protocol-provider.cjs").protocolProvider();
    await legacyFixture(source, mock.baseURL);
    runtime = new Runtime(source, {
      legacyDirectory: path.join(source, "absent"),
    });
    await runtime.start();
    gateway = new Gateway(source, native, runtime);
    await gateway.start();
    globalThis.migrationFixture = {
      count: () => mock.requests.length,
      info: state,
      source,
      target,
      async upgrade({ occupyPort = false, pauseAtData = false } = {}) {
        const port = gateway.port;
        await stop();
        if (occupyPort) {
          blocker = require("node:http").createServer((_q, s) =>
            s.end(
              "<!doctype html><title>测试占用端口</title><p>isolated conflict</p>",
            ),
          );
          await new Promise((resolve, reject) =>
            blocker.once("error", reject).listen(port, "0.0.0.0", resolve),
          );
        }
        progress =
          await require("../../desktop/migration-window.cjs").migrationWindow(
            electron,
          );
        try {
          await migrateLegacy(source, target, safeStorage, {
            onProgress: (v) => progress.update(v),
            onCheckpoint: async (stage) => {
              if (pauseAtData && stage === "data")
                await new Promise((resolve) => {
                  resume = resolve;
                });
            },
          });
        } finally {
          progress.close();
          progress = null;
        }
        runtime = new NodeRuntime(target, { legacySource: source });
        await runtime.start();
        gateway = new Gateway(target, native, runtime);
        await gateway.start();
        return state();
      },
      resume() {
        resume?.();
        resume = null;
      },
      async rollback() {
        await stop();
        await rollbackLegacy(target, rollback, safeStorage);
        runtime = new Runtime(rollback, {
          legacyDirectory: path.join(rollback, "absent"),
        });
        await runtime.start();
        gateway = new Gateway(rollback, native, runtime);
        await gateway.start();
        return state();
      },
      async restoreOriginalOrigin() {
        const port = JSON.parse(
          fs.readFileSync(path.join(source, "network.json")),
        ).port;
        await new Promise((resolve) => blocker.close(resolve));
        blocker = null;
        await gateway.close();
        gateway = new Gateway(target, native, runtime);
        await gateway.start(port);
        return state();
      },
    };
    fs.writeFileSync(
      path.join(directory, "fixture.json"),
      JSON.stringify(state()),
    );
  })
  .catch((error) => {
    fs.writeFileSync(
      path.join(directory, "failed.json"),
      JSON.stringify({ code: error.code || "FIXTURE_FAILED", sqlError: error.code === "ERR_SQLITE_ERROR" ? error.message : undefined, location: String(error.stack || '').split('\n').filter(line => line.trim().startsWith('at ')).slice(0,4) }),
    );
    app.exit(1);
  });
let closing = false;
app.on("before-quit", (event) => {
  if (closing) return;
  event.preventDefault();
  closing = true;
  resume?.();
  Promise.resolve(stop())
    .finally(() => mock?.stop())
    .finally(() => blocker && new Promise((resolve) => blocker.close(resolve)))
    .finally(() => app.exit(0));
});
