const { _electron, expect } = require("@playwright/test"),
  fs = require("node:fs"),
  path = require("node:path");
async function migrationBrowser() {
  const base = path.resolve(".test-data/node-service-m4");
  fs.mkdirSync(base, { recursive: true });
  const directory = fs.mkdtempSync(path.join(base, "browser-")),
    env = { ...process.env, SNAP_MIGRATION_BROWSER_DIR: directory };
  for (const key of [
    "ELECTRON_RUN_AS_NODE",
    "NODE_OPTIONS",
    "NODE_PATH",
    "SNAP_MIGRATION_SOURCE",
    "SNAP_RUNTIME_ENGINE",
  ])
    delete env[key];
  for (const provider of require("../../config/providers.json").providers)
    delete env[provider.envKey];
  const app = await _electron.launch({
    args: [path.resolve("tests/migration/browser-main.cjs")],
    cwd: directory,
    env,
  });
  await expect
    .poll(
      () => {
        if (fs.existsSync(path.join(directory, "failed.json")))
          throw Error("MIGRATION_BROWSER_FIXTURE_FAILED");
        return fs.existsSync(path.join(directory, "fixture.json"));
      },
      { timeout: 60000 },
    )
    .toBe(true);
  const info = JSON.parse(
    fs.readFileSync(path.join(directory, "fixture.json")),
  );
  return {
    ...info,
    app,
    directory,
    count: () => app.evaluate(() => globalThis.migrationFixture.count()),
    upgrade: (options) =>
      app.evaluate(
        (_electron, options) => globalThis.migrationFixture.upgrade(options),
        options,
      ),
    resume: () => app.evaluate(() => globalThis.migrationFixture.resume()),
    rollback: () => app.evaluate(() => globalThis.migrationFixture.rollback()),
    restoreOrigin: () =>
      app.evaluate(() => globalThis.migrationFixture.restoreOriginalOrigin()),
    stop: () => app.close(),
  };
}
module.exports = { migrationBrowser };
