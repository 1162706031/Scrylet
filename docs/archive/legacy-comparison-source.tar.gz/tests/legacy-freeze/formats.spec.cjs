const { test, expect } = require("@playwright/test");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { spawnSync } = require("node:child_process");
const { createFixture } = require("../fixture.cjs");
const catalog = require("../../config/providers.json");
const { Runtime } = require("../../desktop/runtime.cjs");
const { Gateway } = require("../../desktop/gateway.cjs");
const os = require("node:os");

test("M0.4 freeze actual legacy graph, files, saved drafts and deletion after restart", async ({ page }, info) => {
  const root = path.resolve(".test-data/node-service-formats");
  fs.mkdirSync(root, { recursive: true });
  const directory = fs.mkdtempSync(path.join(root, info.project.name + "-"));
  fs.writeFileSync(path.join(directory, "synthetic-only.json"), '{"synthetic":true}');
  const fixture = await createFixture(directory);
  let restartedRuntime;
  const report = { project: info.project.name, upstream: "0.12.2", directory: path.relative(process.cwd(), directory) };
  try {
    await page.addInitScript(() => {
      window.SpeechSynthesisUtterance = class extends EventTarget { constructor(text) { super(); this.text = text; } };
      Object.defineProperty(window, "speechSynthesis", { configurable: true, value: Object.assign(new EventTarget(), {
        getVoices: () => [{ name: "Fixture Chinese", lang: "zh-CN", voiceURI: "fixture:zh", localService: true }],
        cancel() {}, speak(utterance) { setTimeout(() => utterance.onend?.(), 0); },
      }) });
    });
    await page.goto(fixture.pairingUrl);
    await expect(page.locator("#snap-capture")).toBeEnabled({ timeout: 60000 });
    const editor = page.locator("#chat-input");
    await editor.fill("M0.4 新对话已保存草稿");
    await page.locator("#snap-capture").click();
    await expect.poll(() => page.evaluate(() => JSON.parse(sessionStorage.getItem("chat-input") || "{}").files?.length)).toBe(1);
    const newDraft = await page.evaluate(() => JSON.parse(sessionStorage.getItem("chat-input")));
    await page.reload();
    await expect(editor).toHaveText("M0.4 新对话已保存草稿");
    await editor.fill("M0.4 原始图片问题");
    await page.locator("#send-message-button").click();
    await expect.poll(() => fixture.requests.length).toBe(1);
    await expect(page.getByRole("button", { name: "停止", exact: true })).toBeHidden();
    await expect(page).toHaveURL(/\/c\/[^/]+$/);
    let id = new URL(page.url()).pathname.split("/").at(-1);
    await page.locator('button[aria-label="重新生成"]').click();
    await page.getByRole("button", { name: "重试", exact: true }).click();
    await expect.poll(() => fixture.requests.length).toBe(2);
    await expect(page.getByRole("button", { name: "停止", exact: true })).toBeHidden();
    const edit = page.locator('.user-message button[aria-label="编辑"]').first();
    await edit.focus(); await edit.click();
    await page.locator("textarea").filter({ visible: true }).first().fill("M0.4 编辑保留原分支");
    await page.locator(".user-message").getByRole("button", { name: "发送", exact: true }).click();
    await expect.poll(() => fixture.requests.length).toBe(3);
    await expect(page.getByRole("button", { name: "停止", exact: true })).toBeHidden();
    await expect.poll(async () => Object.keys((await fixture.runtime.request(`/api/v1/chats/${id}`)).chat.history.messages).length).toBe(5);
    const record = await fixture.runtime.request(`/api/v1/chats/${id}`);
    const savedPointer = record.current_message_id;
    // Deliberately diverge pointers through the old API and verify its actual loader.
    const originalAnswer = Object.values(record.chat.history.messages).find(m => m.role === "assistant" && m.parentId === Object.values(record.chat.history.messages).find(m => m.content === "M0.4 原始图片问题").id);
    const imported = await fixture.runtime.request("/api/v1/chats/import", { method: "POST", body: { chats: [{ chat: { ...record.chat,
      migrationProbe: { unknownField: "retain-locally" },
      history: { ...record.chat.history, currentId: originalAnswer.id } }, current_message_id: savedPointer }] } });
    id = imported[0].id;
    await page.goto(fixture.url + `/c/${id}`);
    await expect(page.locator(".user-message")).toContainText("M0.4 编辑保留原分支");
    report.pointerPrecedence = "valid top-level current_message_id before embedded history.currentId";
    await editor.fill("M0.4 历史会话已保存草稿");
    await page.locator("#snap-crop").click();
    await expect(page.locator(".cropper-crop-box")).toBeVisible();
    await page.locator("#snap-attach").click();
    await expect.poll(() => page.evaluate(key => JSON.parse(sessionStorage.getItem(key) || "{}").files?.length, `chat-input-${id}`)).toBe(1);
    const existingDraft = await page.evaluate(key => JSON.parse(sessionStorage.getItem(key)), `chat-input-${id}`);
    await page.reload();
    await expect(editor).toHaveText("M0.4 历史会话已保存草稿");
    await expect(page.locator(".snap-attachment")).toHaveCount(1);
    await page.locator("#snap-voice-settings").click();
    await page.locator("#snap-voice-select").selectOption("fixture:zh");
    await page.locator("#snap-speech-rate").focus();
    await page.locator("#snap-speech-rate").press("ArrowLeft");
    await page.getByRole("button", { name: "关闭声音设置" }).click();
    await page.locator("#snap-read-aloud").click();
    await page.reload();
    await expect(page.locator("#snap-read-aloud")).toHaveAttribute("aria-pressed", "true");
    // Inspect actual IndexedDB names, never browser auth tokens or all storage values.
    const browser = await page.evaluate(async () => ({ databases: typeof indexedDB.databases === "function"
      ? (await indexedDB.databases()).map(d => ({ name: d.name, version: d.version })) : null,
      selectedModels: sessionStorage.getItem("selectedModels"),
      preferences: Object.fromEntries(Object.keys(localStorage).filter(k => /^snap\.(readAloud|speechVoice|speechRate|display|crop\.)/.test(k)).map(k => [k, localStorage.getItem(k)])) }));
    report.browserStorage = { source: "sessionStorage", debounceMs: 500, databases: browser.databases };
    fs.writeFileSync(path.join(directory, "browser-fixture.json"), JSON.stringify({ fixtureVersion: 1, project: info.project.name,
      drafts: [{ key: "chat-input", value: newDraft }, { key: `chat-input-${id}`, value: existingDraft }],
      ...browser }, null, 2));
    // Read every synthetic image through the authenticated gateway, compare disk later.
    report.fileReads = [];
    for (const draft of [newDraft, existingDraft]) for (const file of draft.files) {
      const response = await page.request.get(`${fixture.url}/api/v1/files/${file.id}/content`);
      expect(response.ok()).toBe(true);
      const bytes = await response.body();
      report.fileReads.push({ fileId: file.id, bytes: bytes.length, sha256: crypto.createHash("sha256").update(bytes).digest("hex") });
    }
    const prompts = await fixture.runtime.request("/api/v1/prompts/");
    const prompt = prompts[0];
    await fixture.runtime.request(`/api/v1/prompts/id/${prompt.id}/update`, { method: "POST",
      body: { ...prompt, content: "M0.4 用户修改的提示词，不得被种子覆盖" } });
    await fixture.runtime.saveProvider("alibaba", { apiKey: "", baseUrl: fixture.providerUrl + "/custom/", remove: true });
    expect((await fixture.runtime.providers()).providers.find(p => p.id === "alibaba").configured).toBe(false);
    await page.close();
    await fixture.runtime.stop();
    // A conflicting legacy seed must not resurrect the explicitly deleted key.
    const seedDir = path.join(directory, "no-legacy"); fs.mkdirSync(seedDir, { recursive: true });
    const provider = catalog.providers.find(p => p.id === "alibaba");
    fs.writeFileSync(path.join(seedDir, "api_keys.json"), JSON.stringify({ [provider.legacyKey]: "synthetic-deleted-seed" }));
    const old = {};
    for (const item of catalog.providers) { old[item.envKey] = process.env[item.envKey]; delete process.env[item.envKey]; }
    restartedRuntime = new Runtime(directory, { engine: "legacy", legacyDirectory: seedDir });
    try { await restartedRuntime.start(); }
    finally { for (const item of catalog.providers) { if (old[item.envKey] === undefined) delete process.env[item.envKey]; else process.env[item.envKey] = old[item.envKey]; } }
    const restarted = (await restartedRuntime.providers()).providers.find(p => p.id === "alibaba");
    expect(restarted.configured).toBe(false);
    expect(restarted.baseUrl).toBe(fixture.providerUrl + "/custom");
    expect((await restartedRuntime.request(`/api/v1/prompts/id/${prompt.id}`)).content).toBe("M0.4 用户修改的提示词，不得被种子覆盖");
    const after = await restartedRuntime.request(`/api/v1/chats/${id}`);
    expect(Object.keys(after.chat.history.messages)).toHaveLength(5);
    expect(after.current_message_id).toBe(savedPointer);
    expect(after.chat.history.currentId).toBe(originalAnswer.id);
    expect(after.chat.migrationProbe).toEqual({ unknownField: "retain-locally" });
    report.deletedKeySurvivesRestart = true; report.userPromptSurvivesRestart = true;
    report.unknownChatMetadataSurvivesRestart = true;
    const networkAuto = JSON.parse(fs.readFileSync(path.join(directory, "network.json"), "utf8"));
    const interfaces = os.networkInterfaces;
    try {
      os.networkInterfaces = () => ({ FixtureNIC: [{ family: "IPv4", address: "192.0.2.10", internal: false, netmask: "255.255.255.0", cidr: "192.0.2.10/24" }] });
      fixture.gateway.selectNetwork("192.0.2.10");
    } finally { os.networkInterfaces = interfaces; }
    const reloadedGateway = new Gateway(directory, fixture.gateway.native, restartedRuntime);
    expect(reloadedGateway.preferredNetwork).toEqual({ name: "FixtureNIC", address: "192.0.2.10" });
    expect(reloadedGateway.pairing.list()).toEqual(fixture.gateway.pairing.list());
    report.pairingAndNetworkReload = true;
    // No token, tokenHash, cookie or user authentication state is exported.
    fs.writeFileSync(path.join(directory, "desktop-fixture.json"), JSON.stringify({ fixtureVersion: 1,
      networkAuto, network: JSON.parse(fs.readFileSync(path.join(directory, "network.json"), "utf8")),
      deviceFields: Object.keys(JSON.parse(fs.readFileSync(path.join(directory, "devices.json"), "utf8"))[0]).sort(),
      devices: fixture.gateway.pairing.list(), credentials: "omitted; test-only credential created on replay",
    }, null, 2));
    report.chatId = id; report.messageCount = 5; report.requests = fixture.requests.length;
  } finally { await restartedRuntime?.stop(); await fixture.stop(); }
  const exported = spawnSync(require("electron"), [path.resolve("tests/legacy-freeze/export.cjs"), directory], {
    env: { ...process.env, ELECTRON_RUN_AS_NODE: "1" }, encoding: "utf8", timeout: 30000 });
  if (exported.status !== 0) throw Error("FIXTURE_EXPORT_FAILED: " + exported.stderr);
  const snapshot = JSON.parse(fs.readFileSync(path.join(directory, "database-fixture.json"), "utf8"));
  expect(snapshot.tables.chat_message.rows.length).toBeGreaterThanOrEqual(5);
  for (const read of report.fileReads) expect(snapshot.attachments.find(f => f.fileId === read.fileId)).toMatchObject(read);
  report.schema = Object.fromEntries(Object.entries(snapshot.tables).map(([k, v]) => [k, { columns: v.columns.length, rows: v.rows.length }]));
  fs.writeFileSync(path.join(directory, "report.json"), JSON.stringify(report, null, 2));
  fs.writeFileSync(info.outputPath("report.json"), JSON.stringify(report, null, 2));
  await info.attach("format-report", { path: path.join(directory, "report.json"), contentType: "application/json" });
});
