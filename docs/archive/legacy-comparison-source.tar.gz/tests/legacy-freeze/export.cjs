// Test-only, read-only exporter. Never point it at userData or a live database.
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const root = path.resolve(process.argv[2] || "");
if (!root.startsWith(path.resolve(".test-data/node-service-formats") + path.sep) ||
    !fs.existsSync(path.join(root, "synthetic-only.json"))) throw Error("FIXTURE_DIRECTORY_REQUIRED");
const db = new DatabaseSync(path.join(root, "open-webui/webui.db"), { readOnly: true });
const tables = ["chat", "chat_message", "chat_file", "file", "config", "model", "prompt"];
const snapshot = { fixtureVersion: 1, upstream: "0.12.2", tables: {}, attachments: [] };
const decode = value => { try { return JSON.parse(value); } catch { return value; } };
try {
  snapshot.allTables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name").all().map(r => r.name);
  snapshot.alembic = db.prepare("SELECT * FROM alembic_version").all();
  for (const table of tables) {
    const columns = db.prepare(`PRAGMA table_info("${table}")`).all();
    let rows = table === "config"
      ? db.prepare("SELECT * FROM config WHERE key IN ('openai.api_keys','openai.api_base_urls','openai.api_configs') ORDER BY key").all()
      : db.prepare(`SELECT * FROM "${table}" ORDER BY 1`).all();
    rows = rows.map(row => Object.fromEntries(Object.entries(row).map(([key, value]) => [key,
      typeof value === "string" && (columns.find(c => c.name === key)?.type === "JSON" || key === "value") ? decode(value) : value])));
    if (table === "config") {
      for (const row of rows) if (row.key === "openai.api_keys" && row.value.some(Boolean)) throw Error("FIXTURE_KEYS_NOT_DELETED");
    }
    snapshot.tables[table] = {
      sql: db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name=?").get(table).sql,
      columns, foreignKeys: db.prepare(`PRAGMA foreign_key_list("${table}")`).all(), rows,
    };
  }
  snapshot.userSettings = db.prepare('SELECT settings FROM "user"').all().map(row => decode(row.settings));
  for (const file of snapshot.tables.file.rows) {
    const disk = path.resolve(file.path);
    if (!disk.startsWith(root + path.sep)) throw Error("ATTACHMENT_OUTSIDE_FIXTURE");
    const bytes = fs.readFileSync(disk);
    snapshot.attachments.push({ fileId: file.id, bytes: bytes.length,
      sha256: crypto.createHash("sha256").update(bytes).digest("hex"), base64: bytes.toString("base64") });
  }
  const raw = JSON.stringify(snapshot, null, 2).split(root.replaceAll("\\", "\\\\")).join("<FIXTURE_ROOT>")
    .replace(/http:\/\/127\.0\.0\.1:\d+/g, "http://127.0.0.1:49999");
  fs.writeFileSync(path.join(root, "database-fixture.json"), raw + "\n");
  console.log(JSON.stringify({ tables: tables.length, chats: snapshot.tables.chat.rows.length,
    normalizedMessages: snapshot.tables.chat_message.rows.length, files: snapshot.attachments.length }));
} finally { db.close(); }
