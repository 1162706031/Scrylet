const { defineConfig } = require("@playwright/test");
const base = require("./playwright.config.cjs");
module.exports = defineConfig({ ...base, testDir: "./tests/legacy-freeze", timeout: 240000,
  outputDir: ".test-data/node-service-formats/results", retries: 0,
  use: { ...base.use, actionTimeout: 15000,
    userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile/15E148 Safari/604.1" } });
