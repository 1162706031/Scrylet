if (
  process.platform !== "win32" ||
  process.argv.some((arg) => ["--mac", "--macos", "-m"].includes(arg))
) {
  throw new Error(
    "Mac 打包请使用 npm run dist:mac -- --arch arm64|x64；需要按目标架构生成配置并保留候选包边界。",
  );
}
module.exports = require("./scripts/package-config.cjs").packageConfig({
  platform: "win32",
  arch: "x64",
  profile: "legacy",
});
