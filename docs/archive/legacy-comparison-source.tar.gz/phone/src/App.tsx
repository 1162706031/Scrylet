import React, { useEffect, useRef, useState } from "react";
import type { PublicModel, PublicStatus } from "../../contracts/index.js";
import { id, json, messageOf, read, schemas } from "./api";
import { ConversationView } from "./chat/ConversationView";
import { HistoryPanel } from "./chat/HistoryPanel";
import { useDialogFocus } from "./dialogs";
type Route = { id: string | null; visit: string };
const currentRoute = (): Route => ({
  id: /^\/c\/([A-Za-z0-9_-]+)$/.exec(location.pathname)?.[1] || null,
  visit: id(),
});
export function App({
  migrationNotice = "",
}: {
  migrationNotice?: string;
}): React.JSX.Element {
  useDialogFocus();
  const [route, setRoute] = useState<Route>(currentRoute),
    [status, setStatus] = useState<PublicStatus | null>(null),
    [models, setModels] = useState<PublicModel[]>([]),
    [error, setError] = useState(""),
    [historyOpen, showHistory] = useState(false),
    [historyVersion, refreshHistory] = useState(0);
  const pageClientId = useRef(id()).current;
  const navigate = (chatId: string | null): void => {
    history.pushState(null, "", chatId ? "/c/" + chatId : "/");
    setRoute({ id: chatId, visit: id() });
    showHistory(false);
  };
  useEffect(() => {
    let active = true;
    const poll = async (): Promise<void> => {
      try {
        const next = await read("status", "/snap/api/status");
        if (!active) return;
        setStatus(next);
        setError("");
        if (next.ready && !next.paused) {
          const value = await json("/snap/api/models");
          if (!Array.isArray(value)) throw new Error("MODELS_INVALID");
          const parsed = value.map((m) => schemas.publicModel.parse(m));
          if (active)
            setModels((old) =>
              JSON.stringify(old) === JSON.stringify(parsed) ? old : parsed,
            );
        }
      } catch (cause) {
        if (active) setError(messageOf(cause));
      }
    };
    void poll();
    const timer = setInterval(() => void poll(), 1500),
      pop = (): void => setRoute(currentRoute());
    addEventListener("popstate", pop);
    return () => {
      active = false;
      clearInterval(timer);
      removeEventListener("popstate", pop);
    };
  }, []);
  return (
    <div className="phone-app">
      <header className="app-header">
        <button
          className="icon-button"
          aria-label="打开历史对话"
          onClick={() => showHistory(true)}
        >
          ☰
        </button>
        <a
          className="brand"
          href="/"
          onClick={(e) => {
            e.preventDefault();
            navigate(null);
          }}
        >
          <span className="brand-mark">S</span>
          <span>
            Scrylet<small>把思路看清楚</small>
          </span>
        </a>
        <button
          className="icon-button"
          aria-label="新对话"
          onClick={() => navigate(null)}
        >
          ＋
        </button>
      </header>
      {migrationNotice && (
        <p className="inline-status" role="status">
          {migrationNotice}
        </p>
      )}
      {models.length ? (
        <ConversationView
          key={route.visit}
          routeId={route.id}
          models={models}
          status={status}
          statusError={error}
          clientId={pageClientId}
          changed={() => refreshHistory((n) => n + 1)}
          navigate={navigate}
        />
      ) : (
        <main className="initial">
          <h1>从一个问题开始</h1>
          <p>{error || "正在连接电脑…"}</p>
          <a href="/snap/models">连接模型服务</a>
          <a
            href={
              "/snap/pair?returnTo=" + encodeURIComponent(location.pathname)
            }
          >
            重新配对
          </a>
        </main>
      )}
      {historyOpen && (
        <HistoryPanel
          version={historyVersion}
          onClose={() => showHistory(false)}
          navigate={navigate}
        />
      )}
    </div>
  );
}
