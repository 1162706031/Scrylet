import React, { useEffect, useState } from "react";
import type { Chat } from "../../../contracts/index.js";
import { json, messageOf, read, remember, stored } from "../api";
import { copy } from "./MessageList";
export function HistoryPanel({
  onClose,
  navigate,
  version,
}: {
  onClose(): void;
  navigate(id: string | null): void;
  version: number;
}): React.JSX.Element {
  const [chats, setChats] = useState<Chat[]>([]),
    [search, setSearch] = useState(""),
    [archived, setArchived] = useState(false),
    [cursor, setCursor] = useState<string | null>(null),
    [error, setError] = useState(""),
    [menu, setMenu] = useState<string | null>(null),
    [rename, setRename] = useState<Chat | null>(null),
    [title, setTitle] = useState(""),
    [share, setShare] = useState<Chat | null>(null);
  const load = async (append = false): Promise<void> => {
    try {
      const page = await read(
        "chatPage",
        `/snap/api/chats?limit=30&archived=${archived}&search=${encodeURIComponent(search)}${append && cursor ? "&cursor=" + cursor : ""}`,
      );
      setChats((old) => (append ? [...old, ...page.items] : page.items));
      setCursor(page.nextCursor);
    } catch (cause) {
      setError(messageOf(cause));
    }
  };
  useEffect(() => {
    void load();
  }, [search, archived, version]);
  const action = (fn: () => Promise<unknown>): void => {
    setMenu(null);
    void fn()
      .then(() => load())
      .catch((cause) => setError(messageOf(cause)));
  };
  const patch = (chat: Chat, fields: object): Promise<Chat> =>
    read(
      "chat",
      `/snap/api/chats/${chat.id}`,
      { apiVersion: 1, version: chat.version, ...fields },
      "PATCH",
    );
  const exportChat = async (
    chat: Chat,
    format: "json" | "txt" | "pdf",
  ): Promise<void> => {
    const exports = await import("../exports");
    await exports.exportChat(chat, format);
  };
  return (
    <div className="modal-backdrop history-backdrop">
      <aside
        className="history-panel"
        role="dialog"
        aria-modal="true"
        aria-label="历史对话"
      >
        <header>
          <h2>你的对话</h2>
          <button aria-label="关闭历史" onClick={onClose}>
            ×
          </button>
        </header>
        <button className="new-chat" onClick={() => navigate(null)}>
          ＋ 新对话
        </button>
        <input
          aria-label="搜索对话"
          placeholder="搜索对话和消息"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <div className="history-filters">
          <button aria-pressed={!archived} onClick={() => setArchived(false)}>
            对话
          </button>
          <button aria-pressed={archived} onClick={() => setArchived(true)}>
            已归档
          </button>
          <button
            onClick={() =>
              action(() => json("/snap/api/chats/read", { apiVersion: 1 }))
            }
          >
            标记全部已读
          </button>
        </div>
        {error && <p role="alert">{error}</p>}
        <details
          open={stored("snap.historyExpanded") !== "false"}
          onToggle={(event) =>
            remember("snap.historyExpanded", String(event.currentTarget.open))
          }
        >
          <summary>对话</summary>
          <ul>
            {chats.map((chat) => (
              <li key={chat.id}>
                <a
                  href={"/c/" + chat.id}
                  onClick={(event) => {
                    event.preventDefault();
                    navigate(chat.id);
                  }}
                >
                  {chat.pinned && <span aria-label="已置顶">⌖ </span>}
                  {chat.title}
                  {(chat.lastReadAt === null ||
                    chat.updatedAt > chat.lastReadAt) && (
                    <span className="unread" aria-label="未读" />
                  )}
                </a>
                <button
                  aria-label={"对话菜单 " + chat.title}
                  onClick={() => setMenu(menu === chat.id ? null : chat.id)}
                >
                  ···
                </button>
                {menu === chat.id && (
                  <menu>
                    <button
                      onClick={() => {
                        setRename(chat);
                        setTitle(chat.title);
                        setMenu(null);
                      }}
                    >
                      重命名
                    </button>
                    <button
                      onClick={() =>
                        action(() => patch(chat, { pinned: !chat.pinned }))
                      }
                    >
                      {chat.pinned ? "取消置顶" : "置顶"}
                    </button>
                    <button
                      onClick={() =>
                        action(() => patch(chat, { lastReadAt: 0 }))
                      }
                    >
                      标记为未读
                    </button>
                    <button
                      onClick={() =>
                        action(() => patch(chat, { archived: !chat.archived }))
                      }
                    >
                      {chat.archived ? "恢复归档" : "归档"}
                    </button>
                    <button
                      onClick={() =>
                        action(async () => {
                          const clone = await read(
                            "chat",
                            `/snap/api/chats/${chat.id}/clone`,
                            { apiVersion: 1 },
                          );
                          navigate(clone.id);
                        })
                      }
                    >
                      克隆
                    </button>
                    <button
                      onClick={() => {
                        setShare(chat);
                        setMenu(null);
                      }}
                    >
                      分享
                    </button>
                    {(["json", "txt", "pdf"] as const).map((format) => (
                      <button
                        key={format}
                        onClick={() => action(() => exportChat(chat, format))}
                      >
                        下载 {format.toUpperCase()}
                      </button>
                    ))}
                    <button
                      onClick={() => {
                        setMenu(null);
                        if (confirm("确认删除对话？"))
                          action(() =>
                            json(
                              `/snap/api/chats/${chat.id}`,
                              { apiVersion: 1, version: chat.version },
                              "DELETE",
                            ),
                          );
                      }}
                    >
                      删除对话
                    </button>
                  </menu>
                )}
              </li>
            ))}
          </ul>
        </details>
        {!chats.length && <p className="muted">还没有匹配的对话</p>}
        {cursor && <button onClick={() => void load(true)}>加载更多</button>}
        {rename && (
          <form
            className="dialog nested-dialog"
            role="dialog"
            aria-label="重命名对话"
            onSubmit={(event) => {
              event.preventDefault();
              action(() => patch(rename, { title }));
              setRename(null);
            }}
          >
            <h3>重命名对话</h3>
            <input
              aria-label="对话标题"
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              autoFocus
            />
            <button type="button" onClick={() => setRename(null)}>
              取消
            </button>
            <button type="submit">保存标题</button>
          </form>
        )}
        {share && (
          <section
            className="dialog nested-dialog"
            role="dialog"
            aria-label="分享对话"
          >
            <h3>分享对话</h3>
            <p>同一局域网中，已配对的设备可打开这个对话。</p>
            <input
              aria-label="对话链接"
              readOnly
              value={location.origin + "/c/" + share.id}
            />
            <button
              onClick={() =>
                void copy(location.origin + "/c/" + share.id).catch(() =>
                  setError("复制失败，请长按选择链接复制"),
                )
              }
            >
              复制链接
            </button>
            <button onClick={() => setShare(null)}>关闭</button>
          </section>
        )}
      </aside>
    </div>
  );
}
