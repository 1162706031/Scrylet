import React, { useState } from "react";
import Markdown from "react-markdown";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math";
import rehypeKatex from "rehype-katex";
import "katex/dist/katex.min.css";
import type { UIMessage } from "ai";
import type { Chat, Message } from "../../../contracts/index.js";
export async function copy(text: string): Promise<void> {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return;
    }
  } catch {
    /* A LAN origin or denied permission may require the selection path. */
  }
  const element = document.createElement("textarea");
  element.value = text;
  element.style.position = "fixed";
  element.style.opacity = "0";
  document.body.append(element);
  element.select();
  const ok = document.execCommand("copy");
  element.remove();
  if (!ok) throw new Error("COPY_FAILED");
}
export function download(
  name: string,
  value: Blob | string,
  mime = "text/plain",
): void {
  const url = URL.createObjectURL(
    typeof value === "string" ? new Blob([value], { type: mime }) : value,
  );
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = name;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 30000);
}
function Code({
  text,
  language,
}: {
  text: string;
  language: string;
}): React.JSX.Element {
  const [error, setError] = useState("");
  return (
    <details className="code-block" open>
      <summary>
        <span>{language || "代码"}</span>
        <span className="code-controls">
          <button
            type="button"
            onClick={(event) => {
              event.preventDefault();
              void copy(text).catch(() => setError("可长按选择代码复制"));
            }}
          >
            复制代码
          </button>
          <button
            type="button"
            onClick={(event) => {
              event.preventDefault();
              download(
                "code." +
                  (language === "python"
                    ? "py"
                    : language === "javascript"
                      ? "js"
                      : "txt"),
                text,
              );
            }}
          >
            保存代码
          </button>
          <span>折叠 / 展开</span>
        </span>
      </summary>
      <pre>
        <code>{text}</code>
      </pre>
      {error && <small>{error}</small>}
    </details>
  );
}
export function RichText({ text }: { text: string }): React.JSX.Element {
  return (
    <Markdown
      remarkPlugins={[remarkGfm, remarkMath]}
      rehypePlugins={[[rehypeKatex, { trust: false, strict: "ignore" }]]}
      skipHtml
      components={{
        pre: ({ children }) => <div>{children}</div>,
        code: ({ children, className }) =>
          String(children).includes("\n") || className ? (
            <Code
              text={String(children).replace(/\n$/, "")}
              language={className?.replace("language-", "") || ""}
            />
          ) : (
            <code>{children}</code>
          ),
        a: ({ href, children }) => (
          <a
            href={
              href &&
              /^(https?:|mailto:|\/)/.test(href) &&
              !href.startsWith("//")
                ? href
                : undefined
            }
            target="_blank"
            rel="noreferrer"
          >
            {children}
          </a>
        ),
        img: ({ src, alt }) =>
          typeof src === "string" && src.startsWith("/snap/api/files/") ? (
            <img src={src} alt={alt || "消息图片"} loading="lazy" />
          ) : (
            <span>{alt || "外部图片未自动加载"}</span>
          ),
        table: ({ children }) => (
          <div className="table-scroll">
            <table>{children}</table>
          </div>
        ),
      }}
    >
      {text.replace(/<think\b[^>]*>[\s\S]*?<\/think>/gi, "")}
    </Markdown>
  );
}
export function MessageList({
  messages,
  graph,
  busy,
  onEdit,
  onDelete,
  onRetry,
  onBranch,
  onPreview,
}: {
  messages: UIMessage[];
  graph: Chat | null;
  busy: boolean;
  onEdit(message: Message): void;
  onDelete(message: Message): void;
  onRetry(message: Message, style: "retry" | "detail" | "concise"): void;
  onBranch(id: string): void;
  onPreview(src: string): void;
}): React.JSX.Element {
  const [copyError, setCopyError] = useState("");
  return (
    <section
      className="messages"
      aria-label="对话消息"
      role="log"
      aria-live="polite"
    >
      {messages.map((message) => {
        const record = graph?.messages.find((m) => m.id === message.id),
          siblings = record
            ? graph?.messages.filter(
                (m) =>
                  m.role === record.role &&
                  m.parentMessageId === record.parentMessageId,
              ) || []
            : [];
        const position = siblings.findIndex((m) => m.id === record?.id),
          text = message.parts
            .filter((p) => p.type === "text")
            .map((p) => p.text)
            .join("\n");
        return (
          <article
            className={"message " + message.role}
            key={message.id}
            data-message-id={message.id}
          >
            <header>
              <strong>{message.role === "user" ? "你" : "Scrylet"}</strong>
              {record?.modelId && <small>{record.modelId}</small>}
              {record?.status &&
                ["stopped", "failed", "interrupted"].includes(
                  record.status,
                ) && (
                  <span className="state-tag">
                    {record.status === "stopped"
                      ? "已停止"
                      : record.status === "failed"
                        ? "生成失败"
                        : "已中断，未自动重发"}
                  </span>
                )}
            </header>
            <div className="message-parts">
              {message.parts.map((part, index) =>
                part.type === "text" ? (
                  <RichText key={index} text={part.text} />
                ) : part.type === "reasoning" ? (
                  <details className="reasoning" key={index}>
                    <summary>推理内容</summary>
                    <RichText text={part.text} />
                  </details>
                ) : part.type === "file" ? (
                  <button
                    className="message-image"
                    key={index}
                    aria-label="查看消息图片"
                    onClick={() => onPreview(part.url)}
                  >
                    <img src={part.url} alt="消息图片" />
                  </button>
                ) : null,
              )}
            </div>
            <footer className="message-actions">
              <button
                onClick={() =>
                  void copy(text).catch(() =>
                    setCopyError("复制失败，请长按选择文字复制"),
                  )
                }
              >
                复制
              </button>
              {record && (
                <>
                  <button disabled={busy} onClick={() => onEdit(record)}>
                    编辑消息
                  </button>
                  <button disabled={busy} onClick={() => onDelete(record)}>
                    删除消息
                  </button>
                  {record.role === "assistant" && (
                    <details className="retry-menu">
                      <summary aria-label="重新生成">重新生成</summary>
                      <div>
                        {(
                          [
                            ["retry", "重试"],
                            ["detail", "添加详情"],
                            ["concise", "精炼表达"],
                          ] as const
                        ).map(([style, label]) => (
                          <button
                            disabled={busy}
                            key={style}
                            onClick={() => onRetry(record, style)}
                          >
                            {label}
                          </button>
                        ))}
                      </div>
                    </details>
                  )}
                </>
              )}
              {siblings.length > 1 && (
                <span className="branches">
                  <button
                    aria-label="上一条消息"
                    disabled={busy || position <= 0}
                    onClick={() => {
                      const m = siblings[position - 1];
                      if (m) onBranch(m.id);
                    }}
                  >
                    ‹
                  </button>
                  <span>
                    {position + 1} / {siblings.length}
                  </span>
                  <button
                    aria-label="下一条消息"
                    disabled={busy || position >= siblings.length - 1}
                    onClick={() => {
                      const m = siblings[position + 1];
                      if (m) onBranch(m.id);
                    }}
                  >
                    ›
                  </button>
                </span>
              )}
            </footer>
          </article>
        );
      })}
      {copyError && <p role="status">{copyError}</p>}
    </section>
  );
}
