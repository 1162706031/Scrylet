const { defineConfig } = require("@playwright/test");
const base = require("./playwright.config.cjs");
module.exports = defineConfig({ ...base, testDir: "./tests/phone", timeout: 90000, retries: 0,
  outputDir: ".test-data/node-service-m2/results", use: { ...base.use, actionTimeout: 15000,
    userAgent: "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 Version/18.0 Mobile/15E148 Safari/604.1" } });
