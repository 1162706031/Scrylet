// The retained legacy implementation is available only through an explicit opt-in.
const metadata = require("../package.json");
function runtimeDefault(manifest = metadata) {
  if (manifest.scryletRuntimeDefault === "legacy") return "legacy";
  if (manifest.scryletRuntimeDefault === "node") return "node";
  throw new Error("缺少明确的聊天运行层默认配置");
}
class Runtime {
  constructor(directory, options = {}) {
    const engine = options.engine || process.env.SNAP_RUNTIME_ENGINE || runtimeDefault();
    if (engine === "legacy") {
      if (metadata.scryletBuild?.runtime === "node-candidate") throw new Error("此轻量候选包不包含旧运行层，请使用独立的旧版安装与回退副本");
      return new (require("./legacy-runtime.cjs").Runtime)(directory, options);
    }
    if (engine !== "node") throw new Error("未知的聊天运行层");
    return new (require("./node-runtime.cjs").NodeRuntime)(directory, options);
  }
}
module.exports = { Runtime, runtimeDefault };
for (const name of ["seedConnections", "freePort", "VERSION"]) Object.defineProperty(module.exports, name, { enumerable: true, get: () => require("./legacy-runtime.cjs")[name] });
