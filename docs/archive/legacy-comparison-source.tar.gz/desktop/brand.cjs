const fs = require("node:fs");
const path = require("node:path");

const NAME = "Scrylet";
// Preserve the installed application identity so NSIS upgrades the old app.
const APP_ID = "com.snapsolver.desktop";

function legacyDataDirectory(appData) {
  return path.join(appData, "Snap-Solver");
}

function dataDirectory(appData, override, engine = "node") {
  if (override) return path.resolve(override);
  const legacy = legacyDataDirectory(appData);
  if (engine === "legacy" && fs.existsSync(legacy) && fs.statSync(legacy).isDirectory()) return legacy;
  return path.join(appData, NAME);
}

function migrationSource(appData, override, explicitSource) {
  if (explicitSource) return path.resolve(explicitSource);
  const target = dataDirectory(appData, override);
  if (fs.existsSync(path.join(target, "chat-node/v1/migration.json"))) return null;
  const source = legacyDataDirectory(appData);
  return fs.existsSync(path.join(source, "open-webui/webui.db")) ? source : null;
}

module.exports = { NAME, APP_ID, dataDirectory, legacyDataDirectory, migrationSource };
