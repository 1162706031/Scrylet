// Explicit historical comparison paths, never shipped in the Node candidate.
const path = require("node:path");
function runtimePaths(options = {}) {
  const root = options.root || path.resolve(__dirname, ".."),
    resources = options.resourcesPath || process.resourcesPath;
  const platform = options.platform || process.platform;
  const paths = require("./runtime-paths.cjs").runtimePaths({
    ...options,
    root,
    resourcesPath: resources,
  });
  return {
    ...paths,
    python:
      (options.pythonOverride ?? process.env.SNAP_PYTHON) ||
      (paths.packaged
        ? path.join(
            resources,
            "python",
            platform === "win32" ? "python.exe" : "bin/python3",
          )
        : path.join(
            root,
            ".runtime",
            platform === "win32" ? "Scripts/python.exe" : "bin/python",
          )),
    launcher: paths.packaged
      ? path.join(resources, "runtime/launch.py")
      : path.join(root, "runtime/launch.py"),
    mouse: paths.packaged
      ? path.join(resources, "runtime/mouse-input.py")
      : path.join(root, "desktop/mouse-input.py"),
  };
}
module.exports = { runtimePaths };
