// Retained comparison adapter; excluded from Node-only candidate resources.
const httpProxy = require("http-proxy");
const { restrict } = require("./product-scope.cjs");
const extension =
  '<script src="/snap/assets/quiet.js"></script><link rel="stylesheet" href="/snap/assets/mobile.css"><script type="module" src="/snap/assets/extension.js"></script>';
function createLegacyProxy(gateway, unavailable) {
  const proxy = httpProxy.createProxyServer({
    ws: true,
    changeOrigin: true,
    selfHandleResponse: true,
  });
  proxy.on("error", (_error, request, response) => {
    if (typeof response?.writeHead === "function" && !response.headersSent) {
      unavailable(request, response, 502, "聊天服务暂时不可用，请查看电脑 App");
    } else response?.destroy();
  });
  proxy.on("proxyRes", (upstream, request, response) => {
    if (
      request.method === "POST" &&
      request.url.split("?")[0] === "/api/chat/completions"
    )
      gateway.activity?.record(
        upstream.statusCode < 400 ? "chat.requested" : "chat.failed",
      );
    const headers = { ...upstream.headers };
    delete headers["access-control-allow-origin"];
    delete headers["access-control-allow-credentials"];
    headers["cache-control"] = "no-store";
    headers["referrer-policy"] = "no-referrer";
    headers["x-content-type-options"] = "nosniff";
    if (String(headers["content-type"]).includes("text/html")) {
      const chunks = [];
      upstream.on("data", (chunk) => chunks.push(chunk));
      upstream.on("end", () => {
        if (response.destroyed) return;
        const html = Buffer.concat(chunks)
          .toString("utf8")
          .replace("</head>", extension + "</head>");
        delete headers["content-length"];
        delete headers["content-encoding"];
        response.writeHead(upstream.statusCode, headers);
        response.end(html);
      });
    } else {
      response.writeHead(upstream.statusCode, headers);
      upstream.pipe(response);
    }
    upstream.on("error", () => response.destroy());
  });
  return proxy;
}
function mountLegacyGateway(gateway, unavailable) {
  gateway.app.use(restrict);
  gateway.app.use((request, response) => {
    if (!gateway.runtime.ready)
      return unavailable(
        request,
        response,
        503,
        gateway.runtime.error || "聊天服务正在启动，请稍后重试",
      );
    // The single-user backend only listens on loopback. Never accept injected
    // trusted-user headers from a remote client.
    for (const header of Object.keys(request.headers)) {
      if (
        header.startsWith("x-forwarded-") ||
        header.startsWith("x-openwebui-")
      )
        delete request.headers[header];
    }
    request.headers["accept-encoding"] = "identity";
    // The gateway already checked the browser's same origin. The private
    // backend sees one stable origin, even after the computer changes Wi-Fi.
    if (request.headers.origin) request.headers.origin = gateway.runtime.url;
    gateway.proxy.web(request, response, { target: gateway.runtime.url });
  });
}
module.exports = { createLegacyProxy, mountLegacyGateway };
